"""Apply the recorded selection/test protocol without refitting historical predictors."""
from pathlib import Path
import sys,json,hashlib,math,platform
from statistics import NormalDist
import numpy as np
ROOT=Path(__file__).resolve().parent; ROUND=ROOT/'expected'
import argparse
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output-dir',type=Path,required=True)
OUT=parser.parse_args().output_dir;OUT.mkdir(parents=True,exist_ok=True)
APP=ROOT/'application';sys.path.insert(0,str(APP/'src'))
from compass.policy.validation import partition_case_ids,freeze_from_validation,evaluate_frozen
from compass.policy.governance import canonical_bytes,digest
GAMMAS=[.01,.05,.1,.15,.2,.3,.4,.5,.6,.7,.8,.9,.95,.99,.995,.999]
SPECS={'assistments':('inputs/assistments',1000),'oulad':('inputs/oulad',500),'synthetic':('inputs/synthetic',100)}

def save(name,obj): (OUT/name).write_bytes(canonical_bytes(obj))
def wilson(x,n,alpha=.05):
 if not n:return [None,None]
 z=NormalDist().inv_cdf(1-alpha/2); p=x/n;d=1+z*z/n;c=(p+z*z/(2*n))/d;h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
 return [max(0,c-h),min(1,c+h)]
def intervals(m):
 if m is None:return None
 result={'utility':wilson(round(m['utility_at_k']*m['n_selected']),m['n_selected']) if m['utility_at_k'] is not None else [None,None],
 'coverage':wilson(m['n']-m['n_abstained'],m['n']),'selection_rate':wilson(m['n_selected'],m['n'])}
 g=list(m['group_counts'].values())
 if len(g)==2 and all(v['positive'] for v in g):
  lo0,hi0=wilson(g[0]['positive_selected'],g[0]['positive'],.025);lo1,hi1=wilson(g[1]['positive_selected'],g[1]['positive'],.025)
  low=lo1-hi0;high=hi1-lo0
  result['absolute_gap']=[0 if low<=0<=high else min(abs(low),abs(high)),max(abs(low),abs(high))]
 else:result['absolute_gap']=[None,None]
 return result

protocol=ROUND/'PROTOCOLO_SELECAO_TESTE.md';protohash=hashlib.sha256(protocol.read_bytes()).hexdigest()
report={'scope':'retrospective fixed-score split; previously inspected historical data, no new model fit or pristine prospective holdout',
'protocol_sha256':protohash,'python':platform.python_version(),'intervals':'conditional Wilson; gap from simultaneous Bonferroni Wilson TPR bounds; not student-cluster robust', 'datasets':{}}
# Phase 1: partition and select using only validation labels; persist ALL choices before test evaluation.
loaded={}; freezes={}; partitions={}
for name,(relative,k) in SPECS.items():
 path=ROOT/relative/'artifacts/decision_packets.jsonl';rows=[json.loads(s) for s in path.read_text().splitlines()]
 ids=[str(r['case_id']) for r in rows];part=partition_case_ids(ids,name);index={i:j for j,i in enumerate(ids)}
 ix=np.array([index[i] for i in part['validation']]); ti=np.array([index[i] for i in part['test']])
 p=np.array([r['score'] for r in rows]);y=np.array([r['y_true'] for r in rows]);g=np.array([r['sensitive'] for r in rows])
 policy={'schema_version':'2.0','mode':'allocation','descending':True,'topk':{'k':k},
 'abstain':{'enabled':True,'unit':'bits','scope':'global'},'ecl':{'enabled':True,'constraints':{'max_delta_eopp_at_k':.05,'min_coverage':.5}},
 'mas':{'grid':{'k':[k],'gamma_entropy':GAMMAS},'tie_breakers':['min_abs_delta_eopp','max_utility','min_abstain_rate'],'tolerances':{}}}
 freezes[name]=freeze_from_validation(p[ix],y[ix],g[ix],np.array(ids)[ix],policy)
 partitions[name]=part; loaded[name]=(p,y,g,np.array(ids),ti)
 report['datasets'][name]={'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'n_validation':len(ix),'n_test':len(ti),'k':k}
save('partitions.json',partitions);save('frozen_policies.json',{'protocol_sha256':protohash,'choices':freezes})
freeze_file_hash=hashlib.sha256((OUT/'frozen_policies.json').read_bytes()).hexdigest()
# Phase 2: test metrics. No calls to the selector below this point.
for name,(p,y,g,ids,ti) in loaded.items():
 frozen=freezes[name]; test=evaluate_frozen(frozen,p[ti],y[ti],g[ti],ids[ti])
 selected=frozen['selection_report']['selected'];validation={k:v for k,v in selected.items() if k not in {'policy','candidate_id'}} if selected else None
 report['datasets'][name].update({'validation_selection':frozen['selection_report'],'test':test,
 'validation_intervals':intervals(validation),'test_intervals':intervals(test['metrics'])})
assert hashlib.sha256((OUT/'frozen_policies.json').read_bytes()).hexdigest()==freeze_file_hash
report['frozen_file_sha256']=freeze_file_hash;report['partition_sha256']=hashlib.sha256((OUT/'partitions.json').read_bytes()).hexdigest()
save('selection_test_report.json',report)
