"""Verify bundle hashes and reproduce fixed-score selection, fault contracts and tests."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,platform,subprocess,sys
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-dir',type=Path,default=ROOT/'actual');a=p.parse_args();out=a.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
manifest=json.loads((ROOT/'manifest.json').read_text())
for name,record in manifest['files'].items():
 file=ROOT/name
 if hashlib.sha256(file.read_bytes()).hexdigest()!=record['sha256']:raise SystemExit('Hash mismatch: '+name)
env=os.environ.copy();env['PYTHONPATH']=str(ROOT/'application/src')
subprocess.run([sys.executable,str(ROOT/'selection_test.py'),'--output-dir',str(out)],env=env,check=True,cwd=ROOT)
sys.path.insert(0,str(ROOT/'application/src'))
spec=importlib.util.spec_from_file_location('fault_contracts',ROOT/'application/scripts/verify_fault_contracts.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
faults=module.run_contracts();(out/'fault_contracts.json').write_text(json.dumps(faults,indent=2)+'\n')
from verify_export_contract import verify
contract=verify(faults['cases'])
(out/'export_contract.json').write_text(json.dumps(contract,indent=2)+'\n')
comparisons={}
for name in ['partitions.json','frozen_policies.json','selection_test_report.json','fault_contracts.json']:
 expected=json.loads((ROOT/'expected'/name).read_text());actual=json.loads((out/name).read_text())
 if name=='selection_test_report.json':
  expected.pop('python',None);actual.pop('python',None)
 if actual!=expected:raise SystemExit('Expected/observed mismatch: '+name)
 comparisons[name]='exact structural match (Python patch version excluded)'
result=subprocess.run([sys.executable,'-m','pytest','--junitxml='+str(out/'tests.xml')],cwd=ROOT/'application',env=env,text=True,capture_output=True)
(out/'pytest.log').write_text(result.stdout+result.stderr)
if result.returncode:raise SystemExit('Regression tests failed; see '+str(out/'pytest.log'))
from xml.etree import ElementTree as ET
suites=ET.parse(out/'tests.xml').getroot().iter('testsuite');counts=[(int(s.get('tests',0)),int(s.get('failures',0)),int(s.get('errors',0))) for s in suites]
report={'bundle_file_hashes_verified':len(manifest['files']),'comparisons':comparisons,'regression_tests':sum(x[0] for x in counts),
'export_contract_vectors_verified':len(contract['vectors']),'failures':sum(x[1] for x in counts),'errors':sum(x[2] for x in counts),'python':platform.python_version(),
'scope':'Author-run computational reproduction; no retraining of historical predictors; restricted human responses excluded; not independent certification.'}
assert report['regression_tests']==20 and report['failures']==report['errors']==0
(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
