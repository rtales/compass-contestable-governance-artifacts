# Governing by Artifacts executable reviewer bundle

This bundle reproduces the fixed-score validation/test results (Table 15) and seven synthetic fault contracts (Table 16), and runs the 20 application tests. Inputs, code, protocol and expected results are included. It does not require the original author's directory layout or access to participant-level responses.

Use Python 3.12. From this directory:

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.lock
python reproduce.py --output-dir actual
```

On Windows activate `.venv\Scripts\activate` instead. Installing dependencies may require internet; the reproduction command uses the bundled fixed-score inputs and local synthetic test generation. The exact dependency lock is from the revision environment; other platforms or Python versions may require compatibility work.

Expected outcome: exact structural matches for partitions, frozen choices, validation/test reports and all seven fault cases; 20 passing tests. The Python patch-version metadata is excluded from report comparison. Test-generated synthetic training fixtures are distinct from historical real-data predictor fitting, which is not repeated. New outputs are written only under the requested output directory or temporary test directories, leaving expected files intact.

`manifest.json` binds the actual input packets, application source, tests, reproduction scripts and expected outputs. Verify the ZIP checksum received separately as well: a self-contained manifest without a trusted external reference is not proof of authenticity against coordinated rewriting. `paper/` contains the manuscript version accompanying this bundle.

The `utility_at_k` key is retained for compatibility and means selected-set positive outcome rate, not treatment benefit. Gate authorization means technical export permission under declared checks, not institutional approval or remedy. The retrospective split uses previously inspected data and keeps absolute K in each half; it is not a pristine prospective holdout.

Human-study aggregates can be read in the manuscript but cannot be recomputed here: participant-level responses and free-text evidence are excluded. No substitute participants are generated. No formal historical ethics approval is implied. This bundle was checked by the authors after extraction; an evaluator's independent execution remains a separate step.

The application code uses its MIT license. Existing dataset terms and third-party sources retain their own terms; code licensing does not relicense input data. See `DATA_AVAILABILITY.md` for origins and limits.

The fourth-round manuscript formalizes nested acceptance predicates. `verify_export_contract.py` checks the seven actually executed fixture vectors against the manuscript contract, including A implies I implies R and counterexamples to both converses. It writes `export_contract.json`; it adds no claim of universal independence, novelty, or institutional validity. Application Python behavior is unchanged from round 3.
