# Third-round terminology and reviewer package

`Utility@K` / `utility_at_k` is the legacy operational name for the **selected-set positive outcome rate**: observed positive labels among selected cases divided by the realized selection count. It is undefined for empty selection. It does not estimate intervention benefit or need for support. No historical output key, numeric value, optimization criterion or policy is changed by this terminology clarification.

Authorization in `deployment_gate.json` and `authorized_decisions.json` means technical permission to export under the implemented checks. It does not establish institutional authority, legitimate adoption of a rule, delivery of human review or remedy. Existing API names are retained for compatibility.

The reviewer bundle includes fixed-score input packets, expected outputs, application source, tests, a portable reproduction entry point and a SHA-256 manifest. Computational reruns exclude the restricted participant-level responses. The focused literature comparison acknowledges established provenance/version/log mechanisms and does not claim cryptographic or universal integration novelty.
