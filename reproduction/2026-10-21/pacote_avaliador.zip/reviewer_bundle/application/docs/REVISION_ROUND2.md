# Second-round review changes

The verifier now compares the unique packet roster with `run_metadata.json`, so removing an unselected case cannot pass solely because the remaining per-case decisions replay. Metadata and hashes remain unsigned: coordinated rewriting of every record is outside the integrity guarantee.

`compass.policy.validation` separates selection on validation labels from evaluation of one frozen policy. Case partitions depend only on stable IDs and a recorded salt. `evaluate_frozen` verifies the saved choice hash and never searches on test labels. This is fixed-score policy evaluation, not a predictor training/validation/test implementation or prospective deployment authorization. The calling analysis must check that validation and test case IDs are disjoint; the second-round protocol and verifier do so explicitly.

Run the regression checks and synthetic fault contracts:

```bash
PYTHONPATH=src python -m pytest
PYTHONPATH=src python scripts/verify_fault_contracts.py --output /tmp/compass_fault_contracts.json
```

The seven synthetic cases distinguish passive documentation, decision replay, evidence verification and the constraint gate. They are not participant efficacy measurements or a comparison against every auditing toolkit. The separate manuscript revision contains a retrospective selection/test partition, exact aggregate evidence checks and a Word notation repair. No new study participants or historical ethics approval were created.
