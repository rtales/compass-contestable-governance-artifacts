# Comparação bibliográfica focalizada

Consultada em 20/10/2026. Esta é uma comparação de mecanismos descritos, não uma revisão sistemática nem um benchmark executado de ferramentas externas. Não atribuímos ausência de funcionalidades por falta de menção nos textos.

| Fonte primária | Capacidade estabelecida | Consequência para a reivindicação do artigo |
|---|---|---|
| [W3C PROV-O, recomendação de 2013](https://www.w3.org/TR/2013/REC-prov-o-20130430/), seção 3.1 | Vocabulário de entidades, atividades, agentes e relações de derivação | Proveniência não é nova; o contrato específico de decisão é uma especialização, sem alegar conformidade PROV-O implementada. |
| [Vartak et al., ModelDB, HILDA 2016](https://people.csail.mit.edu/mvartak/papers/modeldb-hilda.pdf), seções 1 e 3 | Registro de modelos, pipelines, parâmetros e métricas com histórico de operações | Versionamento e rastreamento de experimentos não são novidades desta proposta. |
| [Ormenisan et al., OpML 2020](https://www.usenix.org/conference/opml20/presentation/ormenisan) | Proveniência de pipelines com captura de mudanças e versões de dados para reprodução/depuração | Replay de escores fixos tem escopo menor que reconstruir um pipeline com dados versionados. |
| [Laurie, Messeri e Stradling, RFC 9162, 2021](https://www.rfc-editor.org/rfc/rfc9162.html), seções 2.1, 4 e 8.2 | Logs de transparência com provas de inclusão/consistência e raízes assinadas | O roster local com hashes não é uma inovação criptográfica nem oferece garantias equivalentes. O domínio da RFC é certificados; ela é usada como referência de mecanismo, não concorrente educacional direto. |
| [Alfrink et al., Contestable AI by Design](https://research.tudelft.nl/en/publications/contestable-ai-by-design-towards-a-framework/) | Contestabilidade sociotécnica como responsividade à intervenção ao longo do ciclo de vida | O contrato executável é um apoio limitado; não implementa sozinho intervenção, recurso e reparação institucional. |

A bibliografia preserva o ano de fascículo 2023 de Alfrink et al.; o portal também registra publicação online em 2022. A proposta não reivindica precedência universal na integração desses componentes. Sua contribuição delimitada é a explicitação e avaliação de um contrato de governança para a regra estudada, incluindo a distinção operacional entre concordância de replay, integridade/completude relativa aos metadados e permissão técnica de exportação.
