"""Check the manuscript's nested predicates against the seven executed fixtures."""
EXPECTED={
'unchanged':(True,True,True),
'score_changed_without_rehash':(True,False,False),
'case_omitted':(True,False,False),
'wrong_model_bytes':(True,False,False),
'wrong_entropy_unit':(True,False,False),
'policy_missing':(False,False,False),
'constraint_violation':(True,True,False),
}
def verify(cases):
    assert len(cases)==len(EXPECTED)
    assert {c['case'] for c in cases}==set(EXPECTED)
    observed={}
    for c in cases:
        R,I,A=(c[k] for k in ['replay_only_accepts','evidence_verifies','gate_authorizes'])
        assert all(type(v) is bool for v in [R,I,A])
        assert (R,I,A)==EXPECTED[c['case']],c['case']
        assert (not A or I) and (not I or R),c['case']
        observed[c['case']]={'R':R,'I':I,'A':A}
    assert any(c['R'] and not c['I'] for c in observed.values())
    assert any(c['I'] and not c['A'] for c in observed.values())
    return {'scope':'Seven synthetic fixtures; operational contract, not universal verification or novelty proof',
            'vectors':observed,'A_implies_I':True,'I_implies_R':True,
            'R_does_not_imply_I_counterexample':'case_omitted',
            'I_does_not_imply_A_counterexample':'constraint_violation'}
