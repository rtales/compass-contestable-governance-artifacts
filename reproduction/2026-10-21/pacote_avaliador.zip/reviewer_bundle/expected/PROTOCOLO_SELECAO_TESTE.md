# Protocolo congelado para partição retrospectiva

Registrado antes de calcular os resultados desta partição. A análise é retrospectiva sobre escores históricos já inspecionados; não é preregistro prospectivo nem teste intocado de todo o pipeline.

- Populações: todos os pacotes históricos ASSISTments, OULAD e sintético usados na revisão, sem novo treinamento.
- Partição: ordenar IDs pelo SHA-256 de `compass-round2-v1|dataset|case_id`, desempatar pelo ID e atribuir a primeira metade (floor n/2) à validação e o restante ao teste. Não estratificar ou reajustar usando labels ou grupos.
- Capacidade absoluta: K=1000,500,100, respectivamente, mantida em validação e teste. Não extrapolar para novos tamanhos de população; Top-K é uma política de lote, não uma previsão individual independente.
- Grade primária: 16 limiares bits [0.01,0.05,0.10,0.15,0.20,0.30,0.40,0.50,0.60,0.70,0.80,0.90,0.95,0.99,0.995,0.999]. Nenhuma seleção de K nesta análise.
- Semântica: allocation, ranking descendente, abstenção global, IDs persistentes, epsilon 1e-7.
- Restrições em validação: gap absoluto de igualdade de oportunidade <=0.05 e cobertura automatizada >=0.50.
- Seleção: viáveis, Pareto exato (max utility, min gap, min abstention), ordem fairness/utility/abstention, tolerâncias zero e menor ID final. Se não houver viável: nenhum escolhido, nenhum teste de política substituta.
- Congelamento: gravar protocolo, IDs de ambas as partições e políticas selecionadas com SHA-256 antes de calcular métricas com labels de teste. Sem retuning após o teste, inclusive se as restrições falharem.
- Relato: contagens de estados/grupos, utility (fração positiva entre selecionados), cobertura (select+reject)/n, selection rate, abstention e gap nos dois conjuntos; status da restrição no teste separado da seleção.
- Incerteza: Wilson 95% para utility/coverage/selection; para diferença de TPR, intervalo conservador obtido de dois intervalos Wilson 97.5% por grupo (Bonferroni), convertido para gap absoluto. Intervalos condicionais por linha: não corrigem dependência entre interações nem incerteza do treinamento/seleção. Sem testes de significância entre datasets.
- Escopo: teste de transporte da escolha de limiar entre partições de escores fixos. A separação de labels impede seleção direta pelo desfecho de teste nesta execução, mas não restaura independência por estudante, temporalidade ou um holdout prospectivo desconhecido.
