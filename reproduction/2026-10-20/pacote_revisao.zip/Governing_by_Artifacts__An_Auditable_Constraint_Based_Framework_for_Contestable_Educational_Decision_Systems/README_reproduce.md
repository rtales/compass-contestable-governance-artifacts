# Reproduction

The authoritative full reanalysis is `../revisao_artigo/scripts/recalcular_evidencias.py`; run it from the project root using the recorded environment. Set `--skip-study` to rebuild computational evidence without participant response files. Candidate CSVs, exact states, uncertainty reports, table sources and the study figure are regenerated from preserved scores and original local responses.

For application tests, run `PYTHONPATH=src python -m pytest` in `../compass_github/compass-contestable-governance-artifacts`. Synthetic integration tests train isolated fixtures, not the historical real-data models.

Supplementary `code/` tools use the shared application via `_runtime.py`; set `COMPASS_APP` if the repository is located elsewhere. Legacy entropy is checked against the bit-based formula before accepting packet input. The old partial reproduce.sh is replaced by a wrapper to the complete revision analysis.

See the root revision directory for the exact software lock, Tectonic release, immutable-source checksums and local evidence paths. No Docker-only or unavailable outputs.zip dependency is claimed.
