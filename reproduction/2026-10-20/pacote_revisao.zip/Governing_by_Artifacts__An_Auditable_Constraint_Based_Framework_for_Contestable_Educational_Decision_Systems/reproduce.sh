#!/usr/bin/env bash
set -euo pipefail
PAPER_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
REVISION_ROOT="${PAPER_DIR}/../revisao_artigo"
exec "${COMPASS_PYTHON:-${REVISION_ROOT}/ambiente/bin/python}" "${REVISION_ROOT}/scripts/recalcular_evidencias.py" "$@"
