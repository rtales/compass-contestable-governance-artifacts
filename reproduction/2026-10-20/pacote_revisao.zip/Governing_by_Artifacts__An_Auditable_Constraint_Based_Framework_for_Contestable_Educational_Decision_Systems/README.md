# Governing by Artifacts — corrected draft

This is the author-selected LaTeX manuscript. The pre-revision source is preserved in `../revisao_artigo/evidencias/fontes_antes_da_revisao.zip` with a SHA-256 inventory.

Compile `main.tex` with a complete LaTeX environment or Tectonic. The source references local figures, tables and bibliography. Rebuild scientific evidence from the parent project using `revisao_artigo/scripts/recalcular_evidencias.py` in the isolated revision environment. This reads preserved historical case packets, not newly fitted predictors.

Generated outputs are in `paper_assets/revised/`; tables and the English diagnostic figure are script-generated. The study computation needs the author's local response ZIP. No individual study responses are included in the generated aggregates.

The implemented targets are success/correctness; the early-warning blueprint is explicitly unevaluated. Historical ECL violations were logged; the revised runner adds a tested export gate. Schema 2.0 supports fixed-score Top-K/abstention, not feature corrections or medical exceptions.

See `../revisao_artigo/README.md` for the inventory, specification, numerical reconciliation, study report, work log and final validation.
