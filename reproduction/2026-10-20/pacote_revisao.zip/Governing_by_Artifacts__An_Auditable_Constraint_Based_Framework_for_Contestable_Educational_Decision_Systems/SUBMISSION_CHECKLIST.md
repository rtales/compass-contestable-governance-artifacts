# Revised draft: submission checks

Use `revisao_artigo/VALIDACAO_E_LIBERACAO.md` and the final verification report. The previous No User Study checklist described another build and was inconsistent with this manuscript.

- [ ] Confirm the venue-specific format and human-subject reporting requirements before submitting.
- [x] Separate success/correctness prediction from a prospective risk-targeting task.
- [x] Declare entropy units, decision states, K ceilings and fixed/variable domains.
- [x] Describe the N=16 exploratory study, assignment and absence of formal committee approval/exemption accurately.
- [x] Avoid redistributing participant responses or asserting that consent substitutes for institutional review.
- [ ] Check the final PDF and evidence package against the recorded verification results.

A technical revision does not establish acceptance by a venue or legal/institutional compliance. No submission has been made by this revision.
