# Operational contestability protocol (reproducible)

This protocol measures *procedural* contestability on top of emitted artifacts, **not** downstream social impact.

## Artifacts used
- `dataset_manifest.json` (dataset hash + schema)
- `policy_profile.yaml` (policy version + constraints + tie-breakers)
- `decision_packets.jsonl` (per-case packet including `packet_hash`, `score`, `entropy`, `y_true`, `sensitive`)

## Tasks
### T1: Decision reconstruction (per case)
Given a `packet_hash` (or `case_id`) and a policy version, reconstruct:
1) the candidate's state `{select, reject, abstain→human review}` under the policy,
2) which constraints were binding (if any),
3) what changed across policy versions (if replayed).

**Measured proxies**
- Artifact touches: {policy, packet, manifest} = 3.
- Scripted runtime (lower bound): computed by `code/replay_and_measure.py`.

### T2: Policy replay (batch)
Given two policy versions differing only in parameters (e.g., K, γ), recompute decisions on the *same* packets.
Report:
- Jaccard overlap of selected sets,
- Count of changed selections,
- Scripted runtime.

## Notes
- These are *mechanism-level* metrics. They are necessary to enable due process, but do not claim to measure stakeholder comprehension or appeal outcomes in the field.
