#!/usr/bin/env python3
"""Selection sensitivity to criterion order, with shared exact Pareto/MAS."""
import argparse,json,itertools
import pandas as pd
from _runtime import select_candidate

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--candidates",required=True);ap.add_argument("--out",required=True)
    ap.add_argument("--max_abs_delta",type=float,default=.05);ap.add_argument("--min_coverage",type=float,default=.5)
    a=ap.parse_args();df=pd.read_csv(a.candidates)
    if "candidate_id" not in df:
        df["candidate_id"]=[f"k={k:06d}:g={g:.6f}" for k,g in zip(df.k,df.gamma_entropy)]
    candidates=df.where(df.notna(),None).to_dict("records")
    sels=[]
    for order in itertools.permutations(["min_abs_delta_eopp","max_utility","min_abstain_rate"]):
        r=select_candidate(candidates,{"max_delta_eopp_at_k":a.max_abs_delta,"min_coverage":a.min_coverage},list(order))
        sels.append({"order":order,"candidate_id":r["selected"]["candidate_id"] if r["selected"] else None})
    report={"n_orders_tested":6,"distinct_selections":len({s["candidate_id"] for s in sels}),"selections":sels,
            "tolerances":{},"pareto":"exact","last_tie_breaker":"ascending candidate_id"}
    open(a.out,"w").write(json.dumps(report,indent=2))
if __name__=="__main__":main()
