#!/usr/bin/env python3
"""Fixed-score replay only; features and normative exceptions are unsupported."""
import argparse,json,time
from _runtime import read_packets,apply_topk_with_abstain

def apply_policy(df,k,gamma):
    d=apply_topk_with_abstain(df.score.to_numpy(),k,gamma,case_ids=df.case_id.astype(str))
    ids=df.case_id.astype(str).to_numpy()
    return set(ids[d["selected"]]),set(ids[d["abstain"]])

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--decision_packets",required=True);ap.add_argument("--out",required=True)
    for side in ["a","b"]:
        ap.add_argument("--k_"+side,type=int,required=True);ap.add_argument("--gamma_"+side,type=float,required=True)
    a=ap.parse_args();df=read_packets(a.decision_packets)
    start=time.perf_counter();sa,aa=apply_policy(df,a.k_a,a.gamma_a);mid=time.perf_counter();sb,ab=apply_policy(df,a.k_b,a.gamma_b);end=time.perf_counter()
    union=sa|sb
    report={"replay_scope":"fixed_scores_topk","entropy_unit":"bits","apply_time_a_s":mid-start,"apply_time_b_s":end-mid,
            "selected_jaccard":len(sa&sb)/len(union) if union else 1.,"selected_changed_count":len(sa^sb),"abstain_changed_count":len(aa^ab)}
    open(a.out,"w").write(json.dumps(report,indent=2))
if __name__=="__main__":main()
