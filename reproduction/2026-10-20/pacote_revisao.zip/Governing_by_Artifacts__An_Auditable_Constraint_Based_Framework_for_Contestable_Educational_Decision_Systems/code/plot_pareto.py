#!/usr/bin/env python3
"""Deterministically plot Pareto fronts from candidates CSVs.

Usage:
  python code/plot_pareto.py --candidates paper_assets/sweeps/assistments_candidates.csv \
    --out figures/pareto_assistments.pdf --selected_k 1000 --selected_gamma 0.999
"""
import argparse
import pandas as pd
import matplotlib.pyplot as plt

def pareto_2d(df, x_col, y_col):
    # minimize x, maximize y
    s = df.sort_values([x_col, y_col], ascending=[True, False]).reset_index(drop=True)
    pareto = []
    best_y = float('-inf')
    for _, r in s.iterrows():
        if r[y_col] > best_y + 1e-12:
            pareto.append(r)
            best_y = r[y_col]
    return pd.DataFrame(pareto)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--candidates', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--selected_k', type=int, required=True)
    ap.add_argument('--selected_gamma', type=float, required=True)
    ap.add_argument('--title', default='')
    args = ap.parse_args()

    df = pd.read_csv(args.candidates)

    # Feasible filter mirrors the paper profile (adjust if needed)
    feasible = df[(df['abs_delta_eopp_at_k'] <= 0.05) & (df['coverage'] >= 0.5)].copy()
    pareto = pareto_2d(feasible, 'abs_delta_eopp_at_k', 'utility_at_k')

    plt.figure(figsize=(5.5,4.2))
    plt.scatter(feasible['abs_delta_eopp_at_k'], feasible['utility_at_k'], marker='o', label='Feasible candidates')
    p = pareto.sort_values('abs_delta_eopp_at_k')
    plt.plot(p['abs_delta_eopp_at_k'], p['utility_at_k'], marker='o', linestyle='-', label='Pareto front (utility vs fairness)')

    sel = feasible[(feasible['k']==args.selected_k) & (feasible['gamma_entropy']==args.selected_gamma)]
    if len(sel)==1:
        plt.scatter([sel.iloc[0]['abs_delta_eopp_at_k']], [sel.iloc[0]['utility_at_k']], marker='*', s=150, label='MAS-selected (highlight)')

    plt.xlabel(r'$|\Delta \mathrm{EOpp}@K|$')
    plt.ylabel('Utility@K (Precision@K)')
    if args.title:
        plt.title(args.title)
    plt.legend(fontsize=7, loc='best', frameon=True)
    plt.tight_layout()
    plt.savefig(args.out)
    plt.close()

if __name__ == '__main__':
    main()
