"""Locate the shared application; validate legacy entropy before accepting it."""
from pathlib import Path
import os, sys, json
import numpy as np
import pandas as pd
app=Path(os.environ.get("COMPASS_APP", Path(__file__).resolve().parents[2]/"compass_github/compass-contestable-governance-artifacts"))
sys.path.insert(0,str(app/"src"))
from compass.policy.decision import binary_entropy, apply_topk_with_abstain
from compass.policy.governance import audit_decisions, select_candidate

def read_packets(path):
    df=pd.DataFrame(json.loads(line) for line in open(path))
    if "entropy_unit" in df and not (df.entropy_unit=="bits").all():
        raise ValueError("Incompatible entropy unit")
    if not np.allclose(binary_entropy(df.score),df.entropy,atol=1e-12,rtol=0):
        raise ValueError("Stored entropy does not match validated bit convention")
    return df
