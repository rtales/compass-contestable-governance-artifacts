#!/usr/bin/env python3
"""Shared bit entropy, inclusive ECE bins and average-rank Spearman."""
import argparse,json
import numpy as np
from scipy.stats import spearmanr
from _runtime import read_packets,binary_entropy

def binary_ece(y,p,n_bins=10):
    idx=np.minimum((p*n_bins).astype(int),n_bins-1)
    return float(sum(np.mean(idx==b)*abs(np.mean(y[idx==b])-np.mean(p[idx==b])) for b in range(n_bins) if np.any(idx==b)))

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--decision_packets",required=True);ap.add_argument("--out",required=True)
    a=ap.parse_args();d=read_packets(a.decision_packets);y=d.y_true.to_numpy();p=d.score.to_numpy();r={"entropy_unit":"bits","spearman_ties":"average"}
    for temp in [1,.5,2]:
        q=np.clip(p,1e-12,1-1e-12);pp=p if temp==1 else 1/(1+np.exp(-np.log(q/(1-q))/temp))
        r["base" if temp==1 else f"T{temp}"]={"ece":binary_ece(y,pp),"spearman_entropy_abs_error":float(spearmanr(binary_entropy(pp),abs(y-pp)).statistic)}
    open(a.out,"w").write(json.dumps(r,indent=2,allow_nan=False))
if __name__=="__main__":main()
