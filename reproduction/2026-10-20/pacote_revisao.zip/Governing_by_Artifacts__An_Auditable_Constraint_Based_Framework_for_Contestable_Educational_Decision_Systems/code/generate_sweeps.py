#!/usr/bin/env python3
"""Replay a declared grid with the shared policy engine; no retraining."""
import argparse
import pandas as pd
from _runtime import read_packets, apply_topk_with_abstain, audit_decisions

def metrics_for(df,k,gamma):
    dec=apply_topk_with_abstain(df.score.to_numpy(),k,gamma,case_ids=df.case_id.astype(str))
    result=audit_decisions(df.y_true.to_numpy(),df.sensitive.to_numpy(),dec["decision"],dec["eligible"])
    return {"k":int(k),"gamma_entropy":float(gamma),"candidate_id":f"k={k:06d}:g={gamma:.6f}",
            **{key:value for key,value in result.items() if key!="group_counts"}}

def main():
    ap=argparse.ArgumentParser()
    for name in ["decision_packets","out_csv","k_grid","gamma_grid"]:ap.add_argument("--"+name,required=True)
    args=ap.parse_args();df=read_packets(args.decision_packets)
    records=[metrics_for(df,int(k),float(g)) for k in args.k_grid.split(",") for g in args.gamma_grid.split(",")]
    pd.DataFrame(records).to_csv(args.out_csv,index=False)
if __name__=="__main__":main()
