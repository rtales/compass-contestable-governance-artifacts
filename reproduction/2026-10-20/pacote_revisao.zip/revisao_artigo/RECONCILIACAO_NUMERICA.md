# Reconciliação numérica

Gerada por `scripts/recalcular_evidencias.py`. Nenhum treinamento foi repetido.

| Dataset | Divergências iniciais por caso | Máxima diferença de utilidade na grade histórica |
|---|---:|---:|
| assistments | 0 | 0 |
| oulad | 0 | 5.55111512313e-17 |
| synthetic | 0 | 1.11022302463e-16 |

As diferenças de escolhas MAS são registradas nos relatórios: perfis variáveis e orçamento fixo têm domínios separados. As novas regras de ID/tolerância não foram atribuídas retrospectivamente ao runner antigo.

Relatórios completos: `PAPER/paper_assets/revised/computational_report.json` e `study_report.json`. Scores e pacotes históricos foram preservados.
