# Validação e critérios de liberação

Estado: protocolo executado com testes da aplicação, smoke tests, reconciliação histórica e inspeção do PDF. Ver RELATORIO_FINAL.md. Itens de campo e compartilhamento foram resolvidos por limitação explícita de escopo, sem alegar implementação inexistente.

## 1. Testes científicos e de decisão

- [x] Labels, unidade e ranking: casos conhecidos comprovam a tarefa descrita em cada recipe.
- [x] Cobertura: `select + reject + abstain = n`; cobertura automatizada mais abstenção soma 1; taxa de seleção distinta.
- [x] Capacidade: selecionados nunca excedem K nem elegíveis; testar capacidade insuficientemente preenchida, K=0 e K maior que n.
- [x] Entropia: p=0/1, p=0.5, valores próximos aos extremos, fronteira u=gamma e entrada inválida; unidade em bits registrada e reproduzível.
- [x] Taxonomias: allocation/screening e abstenção global/local produzem estados conforme especificação. Se algum modo não for implementado, texto não o apresenta como funcionalidade entregue.
- [x] Equidade: conferir numeradores/denominadores manualmente em fixture pequena; grupo sem positivos e labels ausentes geram tratamento explícito.
- [x] Empates por caso: resultados invariantes à ordem das linhas, com IDs persistidos e regra estável.

## 2. ECL, Pareto, MAS e bloqueio

- [x] Fixture com candidato dominado, candidatos equivalentes, múltiplos objetivos e nenhum viável.
- [x] Limiares na fronteira, tolerâncias por critério e NaN documentados.
- [x] Mudança legítima de perfil produz mudança atribuível à política; reexecução com mesmo perfil preserva seleção.
- [x] Permutação dos candidatos não altera escolha nem ID final.
- [x] Resultado inviável não é exportado como decisão autorizada; decisões de avaliação ficam identificadas como candidatas.
- [x] Falta de capacidade humana não é ocultada por rótulo de encaminhamento. Reportar capacidade/necessidade ou limitar a alegação.

## 3. Integridade e replay

- [x] Pacote/política/manifesto íntegros passam verificação; dados adulterados, versão desconhecida e referências ausentes falham de modo explícito.
- [x] Replay sob política original reproduz decisões por caso, estados e métricas com tolerâncias numéricas predefinidas.
- [x] Empates e boundary cases produzem igualdade entre runner e replay.
- [x] Scorecard é resultado de verificações, não constante. Remover ou corromper artefatos modifica o resultado.
- [x] Hash de modelo ajustado é distinto de hash de configuração; provenance permite identificar preprocessing, dados e código.
- [x] Cenário médico depende de insumo/regra presentes ou fica declarado fora do contrato mínimo.
- [x] Mudança de feature exige re-scoring identificado; nunca classificado como replay de scores fixos.

## 4. Resultados computacionais

- [x] Identificar separadamente reconstrução histórica e execução corrigida.
- [x] Reconciliar as grades históricas 5×16 com seus CSVs, contagens de viáveis e fronteiras.
- [x] Reconciliar análises de K fixo com seus próprios domínios, sem apresentar os 80 pontos variáveis como grade fixa.
- [x] Cada escolha tem perfil, K, gamma, unidade, contagens inteiras e métricas exatas.
- [x] Regenerar tabelas/macros/figuras por script; rastrear cada número ao output estruturado.
- [x] ECE, correlação com empates, risco seletivo e intervalos reproduzíveis; unidade de reamostragem compatível com os dados.
- [x] Se houve seleção de política usando labels de avaliação, não chamar o mesmo conjunto de teste independente. Separar validação/teste ou explicitar o caráter exploratório.

## 5. Estudo humano N=16

- [x] Confirmar desenho, mapeamento A/B, ordens, participantes únicos, completude e exclusões.
- [x] Confirmar gabaritos e coincidência observada entre acerto diagnóstico e remediação.
- [x] Comparar agregados recalculados aos originais; explicar qualquer diferença.
- [x] Registrar teste, lado, zeros, empates, método de p-value, continuidade e versão do software.
- [x] Declarar família de testes e correção aplicada; plano analítico revisado identificado como retrospectivo.
- [x] Reportar efeitos pareados e intervalos com unidade participante; não tratar 128 respostas como 128 pessoas independentes.
- [x] Documentação ética/consentimento/recrutamento/compensação verificada ou lacuna declarada; não inventar fatos.
- [x] Compartilhamento de dados compatível com autorizações; outputs públicos sem identificadores ou textos potencialmente identificáveis.
- [x] Figura em inglês, descrição acessível e contagens por caso/condição.

## 6. Manuscrito e apresentação

- [x] Notação, método, apêndices, README e checklist descrevem a mesma versão.
- [x] Nenhuma promessa de implantação fail-closed, custo institucional ou replay ampliado sem evidência.
- [x] Cada referência do claim-evidence map aponta para conteúdo incluído no build.
- [x] Chaves bibliográficas e referências no build conferidas; registro Alfrink corrigido a partir do editor. Afirmações de conformidade jurídica foram retiradas. Não se afirma uma auditoria externa integral de todos os registros bibliográficos.
- [x] Compilação completa sem referências indefinidas; logs examinados.
- [x] Todas as páginas renderizadas e inspecionadas; tabelas sem cortes, sobreposição ou fonte ilegível.
- [x] Dados visíveis conferidos contra fontes exatas; arredondamentos feitos apenas na apresentação.
- [x] DOCX, se produzido, comparado ao LaTeX estabilizado e renderizado separadamente.

## 7. Pacote final

- [x] Ambiente e comandos documentados e suficientes para reprodução limpa.
- [x] Revisão imutável ou snapshot com checksums; nenhum `LOCAL` usado como única identificação do código.
- [x] Inventário inclui somente arquivos realmente fornecidos e condições de acesso a dados externos.
- [x] Todos os O01–O12 e A01–A09 têm estado final, justificativa e evidência.
- [x] Diário contém ações, resultados, limitações e decisões substantivas.
- [x] Publicação/submissão/distribuição realizadas somente quando solicitadas.

## Regra para falhas e trabalho adicional

Executar testes proporcionais às alterações. Corrigir uma falha e repetir os testes afetados; ampliar a bateria quando a mudança atingir outros módulos ou houver incerteza material. Não criar testes que apenas repetem detalhes de implementação sem verificar uma propriedade científica ou operacional.

Uma restrição factual não resolvida exige limitação ou retirada da alegação correspondente. Uma tabela reformatada não comprova correção numérica; um hash não comprova conteúdo verdadeiro; um replay computacional não comprova recurso institucional efetivo.
