# Como executar a revisão passo a passo

Data: 2026-10-20. Este documento explica a execução; não registra correções já realizadas.

## Ciclo de cada etapa

1. Ler o estado atual do diário, da matriz e das decisões.
2. Selecionar um conjunto de problemas com dependências resolvidas.
3. Registrar a hipótese, a fonte de verdade e o resultado esperado.
4. Preservar o estado anterior e realizar a alteração delimitada.
5. Executar testes ou conferências que possam refutar a alteração, incluindo casos de fronteira quando relevantes.
6. Comparar o resultado ao critério de conclusão. Se falhar, corrigir e testar novamente; se depender de fato externo, registrar a pendência e continuar as tarefas independentes.
7. Atualizar os Markdown com arquivos alterados, comandos, evidências, diferenças e limitações.
8. Comunicar ao autor o que foi concluído, o que mudou nos resultados e qual é o próximo passo.

Não é necessário pedir confirmação a cada mudança técnica de rotina dentro de uma execução autorizada. Perguntas ao autor serão reservadas a informações factuais ausentes ou escolhas científicas que alterem o objetivo do estudo. Não apresentar propostas como decisões já tomadas.

## Lotes de trabalho e entregas

| Lote | Trabalho | Entrega verificável |
|---|---|---|
| 1 | Inventariar versões, arquivos incluídos e código histórico; preservar hashes e alterações locais | INVENTARIO_DE_VERSOES.md e mapa de proveniência |
| 2 | Fixar alvo, ranking, cobertura, K, estados e unidades | ESPECIFICACAO_CIENTIFICA.md, com decisões ou pendências explícitas |
| 3 | Corrigir funções compartilhadas de entropia, decisão, ECL, Pareto, MAS e contrato de replay | Código com testes comportamentais e relatório do que passa/falha |
| 4 | Reconstruir resultados históricos e executar políticas corrigidas em saídas distintas | RECONCILIACAO_NUMERICA.md e tabelas geradas, com diferenças explicadas |
| 5 | Auditar dados e métodos do estudo N=16; validar a incerteza | RELATORIO_ESTUDO_N16.md, relatórios de validação e figuras rastreáveis |
| 6 | Atualizar LaTeX, apêndices, bibliografia, tabelas, gráficos e documentação | Manuscrito coerente com os resultados e mapa de alegações/evidências |
| 7 | Compilar, renderizar e conferir tudo; testar o pacote reproduzível | PDF conferido, inventário final e matriz com estado de cada observação |

Os lotes agrupam as 11 etapas do plano principal; não as substituem. A execução avança com base em evidências, sem prometer que todas as etapas caberão em uma única interação.

## Participação necessária do autor

- Confirmar fatos do estudo que os arquivos não documentarem: atribuição das condições, recrutamento, revisão ética ou dispensa, compensação e autorização de compartilhamento.
- Decidir se o artigo manterá a avaliação histórica de sucesso ou passará a incluir novo experimento de risco. Até essa decisão, a reconstrução histórica pode prosseguir.
- Disponibilizar o DOCX apenas se também desejar atribuir e corrigir problemas específicos dessa conversão.

## Estado atual

O ciclo foi autorizado e executado. Inventário, aplicação, reanálises e texto foram corrigidos e verificados. Consulte RELATORIO_FINAL.md, a matriz de correções e o diário para evidências e limites.
