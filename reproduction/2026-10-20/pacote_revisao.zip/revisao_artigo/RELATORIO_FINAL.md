# Relatório final da revisão

Concluído em 2026-10-20, America/Toronto. A execução foi autorizada pelo autor como ciclo de diagnóstico, correção, teste, registro e avanço. O manuscrito selecionado foi corrigido; a cópia da aplicação com Git foi modificada. Fontes anteriores, outputs e respostas originais foram preservados.

## Entregas

- `evidencias/artigo_revisado.pdf`: versão corrigida, compilada e inspecionada; 10 páginas.
- Projeto LaTeX original selecionado, atualizado no lugar, com tabelas e figura regeneradas.
- `compass_github/compass-contestable-governance-artifacts/`: aplicação revisada, testes e documentação v2.
- `evidencias/pacote_revisao.zip`: fontes, scripts, ambiente fixado, dados computacionais necessários, agregados e evidências de teste. Sem respostas individuais do estudo.
- `evidencias/manifesto_revisao_final.json` e `pacote_revisao.sha256`: inventário/hash do snapshot e do ZIP.
- `evidencias/fontes_antes_da_revisao.zip`: cópia anterior local; não é necessário redistribuí-la para reproduzir o pacote corrigido.

## Mudanças principais

1. Tarefa histórica de sucesso/correção explicitada, com teste dos labels OULAD; alerta precoce separado como proposta não avaliada.
2. Entropia compartilhada em bits; coverage automatizada separada de taxa de seleção; K definido como teto, com contagens exatas.
3. ECL/Pareto/MAS integrados, domínio fixo/variável explícito, tolerâncias e IDs; casos sem evidência ou sem candidato viável tratados explicitamente.
4. Verificador real de artefatos, modelo ajustado separado de configuração, hashes dos fontes e exportação condicionada à viabilidade e integridade. Nenhuma fila humana conectada é alegada.
5. Replay limitado ao contrato implementado; tabela de cenários informa regras por escola, exceções e mudanças de features fora do escopo.
6. Estudo N=16 recalculado com atribuição confirmada pelo autor, IC pareados, teste bilateral explícito e Holm. Participação voluntária e ausência de aprovação/dispensa formal de comitê relatadas.
7. Validação de incerteza incluída no build; ECE, Spearman com empates, risco por grupo e intervalos condicionais. Limitação de clusters explícita.
8. Contradições de apêndices/README/checklist removidas, referência Alfrink corrigida, gráfico em inglês com contagens e descrição acessível, tabelas conferidas.

## Evidência de conclusão

- **16 testes passaram**, sem falhas ou skips, na aplicação local (`testes_aplicacao.xml`).
- **16 testes passaram** em cópia extraída do pacote, usando o mesmo ambiente isolado fixado (`testes_pacote_limpo.xml`). Isso comprova independência dos caminhos do checkout, não uma instalação em outro sistema operacional.
- Dois smoke runs persistidos: um viável autoriza exportação; outro inviável não exporta decisões autorizadas. Ambos têm 4/4 checks de integridade/replay realmente executados (`validacao_integrada.json`).
- **112626 pacotes históricos** conferidos: 105107 ASSISTments, 6519 OULAD e 1000 sintético. Todos os hashes de pacotes e políticas dos briefs conferem. Replay inicial tem zero divergências por caso.
- Grades históricas reproduzidas com diferenças finitas inferiores a 1e-12 e os mesmos padrões de utilidade indefinida. Viáveis nas grades 80-pontos: 55, 15 e 12; nos subconjuntos fixos 16-pontos: 11, 3 e 3.
- Relatório computacional e três CSVs reexecutados a partir do pacote extraído ficaram **idênticos byte a byte** (`reproducao_pacote.json`). Estudo explicitamente pulado nessa execução portátil, por exclusão dos dados individuais; os agregados do estudo foram recalculados localmente com o ZIP original.
- 30 arquivos LaTeX incluídos, 35 labels, zero referências internas indefinidas. Compilação final sem overfull boxes, referências indefinidas ou erro fatal; avisos tipográficos de underfull/fontes do motor não impediram a geração.
- Dez páginas renderizadas e inspecionadas. Após as últimas mudanças, páginas 1, 5, 9 e 10 foram reinspecionadas; as outras seis permaneceram pixel a pixel iguais ao render já examinado. Tabelas legíveis e completas.

## Limites preservados no artigo

A correção não cria aprovação ética retrospectiva, nova coleta, motor de exceções médicas, fila humana, validação prospectiva, garantia populacional de equidade nem benefício educacional medido. Esses pontos foram relatados como limites e as alegações que dependiam deles foram retiradas ou restringidas. Não houve re-treinamento dos modelos históricos; novos treinos ocorreram somente em dados sintéticos de teste/smoke. Não houve publicação, submissão ou envio a terceiros.

O DOCX não foi fornecido, então não se atribuiu a ele a origem de um defeito. A observação de recorte da Tabela 11 não se reproduziu no PDF original disponível e foi encerrada com essa evidência.

## Continuidade

As 12 observações e nove achados adicionais têm estado final em `MATRIZ_DE_CORRECOES.md`. O ciclo de correção solicitado está concluído no escopo demonstrado; novos objetivos científicos, submissão a um veículo ou implantação exigem tarefas próprias. A escolha de formato de submissão continua com o autor, sem bloquear esta entrega técnica.
