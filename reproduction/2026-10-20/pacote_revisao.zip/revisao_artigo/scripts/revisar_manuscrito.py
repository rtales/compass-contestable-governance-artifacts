"""Apply the scientific revision to the selected LaTeX sources.
Evidence tables are generated separately by recalcular_evidencias.py.
"""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[2]
P=ROOT/'Governing_by_Artifacts__An_Auditable_Constraint_Based_Framework_for_Contestable_Educational_Decision_Systems'
def write(name,text): (P/name).write_text(text.strip()+'\n')
# Keep author metadata; remove unverified venue/date/DOI placeholders.
p=P/'main.tex';s=p.read_text();s=s.replace(r'\documentclass[sigconf]{acmart}',r'\documentclass[sigconf,nonacm]{acmart}')
s='\n'.join(line for line in s.splitlines() if not line.startswith(('\\acmConference','\\acmBooktitle','\\acmDOI','\\acmISBN')))+'\n'
a=s.index('Automated decision support',s.index(r'\begin{abstract}'));b=s.index(r'\end{abstract}',a)
s=s[:a]+r'''Automated educational decision support requires evidence that decisions followed an explicit institutional policy. We present \compa-\ecl-\mas, an artifact-oriented framework combining empirical constraints, policy versioning, deterministic selection over feasible Pareto candidates, and replay of Top-$K$ decisions with abstention. We evaluate governance mechanics using fixed scored cases from ASSISTments, OULAD and a synthetic stress test. The implemented tasks predict correctness or student success; they do not evaluate early-warning intervention targeting. Reclassifying unselected cases changes automation coverage without necessarily changing selection utility, exposing an institutional choice that must be audited. We reconcile historical outputs with a revised implementation that specifies entropy in bits, stable tie rules, artifact verification and an authorization gate for infeasible candidates. An exploratory, counterbalanced study ($N=16$; eight standardized cases) shows diagnostic and remediation accuracy of 0.563 under logs/cards and 0.922 under structured evidence; correctness on these two endpoints coincides in every response. The study evaluates the evidence bundle as a whole, not an independently isolated replay effect or field recourse. We release reproducible analyses and explicitly distinguish fixed-score replay, new inference, and unsupported feature-dependent exceptions.
'''+s[b:];p.write_text(s)
# Notation corrections.
p=P/'sections/00_notation.tex';s=p.read_text().replace(r'$C$ & coverage $\;=\;|\text{TopK}(\mathcal{E}_\gamma)|/n$',r'$C$ & automation coverage $(n_{\mathrm{sel}}+n_{\mathrm{rej}})/n$').replace('$u_i$ & uncertainty (predictive entropy)','$u_i$ & predictive entropy in bits, $0\leq u_i\leq1$')
s=s.replace('$K$ & intervention budget (Top-$K$)','$K$ & selection capacity ceiling (Top-$K$)');p.write_text(s)
# Scope introduction without changing contextual literature.
p=P/'sections/01_introduction.tex';s=p.read_text().replace(r'\subsection{Contributions (reframed for contestability)}',r'\subsection{Contributions}').replace(r'\paragraph{Scope lock (what we claim / what we do not claim).}',r'\paragraph{Scope.}').replace('due-process-ready infrastructure','auditable infrastructure').replace('complete reproducibility blueprint (code, Docker, and artifact schemas) designed to be populated on public education benchmarks','reproducible fixed-score analyses, a tested reference application, and versioned artifact definitions')
s+='\nThe reported predictors estimate correctness or student success. They are mechanism testbeds, not validated rules for assigning support to the students at greatest risk. A prospective early-warning use requires a separately specified target, horizon and evaluation.\n';p.write_text(s)
write('sections/03_method.tex',r'''
\section{Method: Policy, Decisions and Artifacts}
\label{sec:method}
\subsection{Design scope}
Our design makes institutional choices explicit, preserves evidence for audit, separates scoring from sensitive-attribute auditing, and treats abstention as a request for human consideration. The six COMPASS commitments---dignity, correctness, transparency, harmony, practical wisdom and active compassion---organize requirements; they are a domain-specific design vocabulary, not an exhaustive ethical theory. In the evaluated release the enforced numerical constraints are a fairness-gap cap and an automation-coverage floor. Documentation, intelligibility and institutional recourse remain separate requirements.

\subsection{Decision rule and units}
\label{sec:decision-rule}
A score $s_i$ estimates $\Pr(y_i=1\mid x_i)$. All reported rankings are descending. Binary predictive entropy is
\begin{equation}
 u_i=-q_i\log_2q_i-(1-q_i)\log_2(1-q_i),
\end{equation}
where $q_i$ clips $s_i$ to $[10^{-7},1-10^{-7}]$ in float64. Entropy and $\gamma$ are in bits; the maximum is one. Thus $\gamma=0.999$ need not admit every case. Invalid probabilities and incompatible units are rejected.

The primary rule applies global abstention first: $u_i>\gamma$ yields \texttt{abstain}. Among eligible cases, the highest scores are selected up to capacity $K$. Equal scores are resolved by ascending persistent case ID. $K$ is a ceiling: fewer than $K$ cases may be selected. In allocation mode the remainder is \texttt{reject}; in screening mode it is \texttt{abstain}. The alternative Top-$K$-only abstention mode first nominates the global Top-$K$, abstains uncertain nominees and does not refill their places. These modes are explicit policy fields in the revised implementation.

\input{tables/decision_states}

\paragraph{Metrics.}
Let $n_s,n_r,n_a$ count select, reject and abstain, with $n_s+n_r+n_a=n$. Automation coverage is $C=(n_s+n_r)/n=1-n_a/n$; selection rate is $n_s/n$. In screening mode $C\leq K/n$, so a floor $C_{\min}>K/n$ is structurally infeasible. Changing a deferral into a rejection changes institutional responsibility; it does not demonstrate greater educational benefit.

Utility@K is $\sum_{i:d_i=\mathrm{select}}y_i/n_s$, undefined for empty selection. For binary audit groups we report the absolute gap between $\Pr(d=\mathrm{select}\mid y=1,a=0)$ and $\Pr(d=\mathrm{select}\mid y=1,a=1)$. Positive-label denominators include all cases in each group, not only eligible cases. A missing group or zero positive denominator produces insufficient evidence, not a zero gap. Labels support retrospective evaluation; they are not inputs required to replay a future decision.

\subsection{ECL and the authorization boundary}
\label{sec:ecl}
ECL checks a candidate against declared empirical constraints. The paper sweep uses gap $\leq0.05$ and coverage $\geq0.50$. These are example normative choices, not universal safety thresholds. The historical synthetic recipe used a 0.60 coverage floor; the common replay analysis explicitly uses 0.50. Both reject its initial 0.004 coverage.

Historical runs recorded violations while retaining candidate decisions. The revised runner additionally writes an authorization gate: an infeasible or insufficient-evidence result cannot produce an authorized-decision export. Candidate packets remain available for diagnosis. A review-required record is generated, but no human queue is connected and no delivered review is claimed. Statistical feasibility on an audit sample does not certify future population fairness or legal compliance.

\subsection{Candidate search and MAS}
Candidates in the reported experiment reuse fixed scores and vary policy only. We distinguish the full 80-point $(K,\gamma)$ grid from its 16-point fixed-$K$ subset. Each candidate has an ID defined by dataset, capacity and threshold. The revised runner also supports an explicit policy grid and stores all candidates and the selection report.

\begin{algorithm}[t]
\caption{Revised empirical ECL--Pareto--MAS selection}
\label{alg:mas}
\begin{algorithmic}[1]
\Require Candidates $\mathcal C$, constraints, criteria $T$, tolerances $\delta_t$
\State $F\gets$ candidates with finite objectives satisfying constraints
\If{$F=\varnothing$}
\State \Return infeasible; close authorization gate
\EndIf
\State $F\gets$ nondominated candidates in $F$
\For{criterion $t$ in $T$}
\State $v^*\gets$ best value of $t$ in $F$
\State $F\gets\{c\in F:|t(c)-v^*|\leq\delta_t\}$
\EndFor
\State \Return candidate with smallest persistent ID in $F$
\end{algorithmic}
\end{algorithm}

Pareto dominance is exact over maximize utility, minimize absolute gap and minimize abstention. Equivalent candidates remain on the frontier. Fairness-first orders gap, utility, abstention; utility-first orders utility, gap, abstention. All reported tolerances are zero; the candidate ID is the final tie-breaker. These conventions replace historical underspecification and are recorded with each revised analysis. Repeated selection under an unchanged policy must be invariant to input row order. Changing criterion order tests policy sensitivity, not determinism by itself.
''')
write('tables/decision_states.tex',r'''
\begin{table}[t]
\centering\small
\caption{Candidate decision states. A separate run-level gate determines whether export is authorized.}
\label{tab:decision_states}
\begin{tabularx}{\columnwidth}{lX}
\toprule
State & Accounting \\
\midrule
\texttt{select} & Within capacity; counts toward selection and automation. \\
\texttt{reject} & Automated non-selection; counts toward automation. \\
\texttt{abstain} & Request for review; excluded from automation coverage. \\
\bottomrule
\end{tabularx}
\end{table}
''')
write('sections/04_design_rationale.tex',r'''
\section{Design Properties and Their Limits}
\label{sec:design}
\textbf{G1: Rule-aligned audit.} Metrics and constraint checks use the decision states actually emitted by a specified rule. This prevents a training-score metric from being mistaken for deployed-rule compliance. Historical outputs and revised decisions are reconciled separately.

\textbf{G2: Reproducible policy selection.} With the same scored cases, IDs, candidate domain, objectives, policy and numerical conventions, the revised implementation applies exact Pareto filtering and deterministic tie-breaking. Tests include permuted cases and candidates. This is a computational property, not a claim of stability under new training samples or institutional preferences.

\textbf{G3: Explicit failure.} An empty feasible set or insufficient evidence closes the revised authorization gate. The historical code reported violations but did not establish that operational block. Neither version demonstrates a completed human review or institutional remedy.

\textbf{G4: Evidence integrity.} The revised verifier checks packet hashes, policy content, dataset-manifest bytes, fitted-model bytes, schema fields and decision replay. It never deserializes an untrusted model merely to verify its hash. Passing these checks establishes internal consistency, not truth of the source data, independent authenticity, absence of discriminatory proxies, or meaningful access to recourse.

All numerical constraints are retrospective sample checks. New cases require monitoring and an appropriate evaluation design; generalization guarantees are outside this paper. Raising an entropy threshold can increase automation while admitting more errors. Neither lower abstention nor successful replay establishes improved educational outcomes.
''')
write('sections/05_experiments.tex',r'''
\section{Experimental Setup}
\label{sec:experiments}
\subsection{Historical data and evaluation scope}
We audit fixed scored test cases from three historical runs: ASSISTments interaction correctness ($n=105107$), OULAD student success ($n=6519$) and a synthetic binary stress test ($n=1000$). ASSISTments uses $y=1$ for a correct response and school-ID parity as a synthetic grouping proxy, not a protected attribute. OULAD uses $y=1$ for Pass/Distinction and binary gender for auditing. Appendix~\ref{app:datasets} gives task and split details. These are outcome-prediction testbeds; descending success scores do not prioritize the highest-risk students for intervention.

The historical runner used a seeded shuffled 80/20 split and seed 42. We do not claim a temporal early-warning horizon, student-cluster independence for interaction rows, or prospective treatment effects. The revision replays emitted scores without retraining historical models. Policy search uses labels from the same retrospective audit sample, so selected operating points are exploratory, not an independently validated final policy.

\subsection{Policy domains}
All datasets use the threshold grid $\{.01,.05,.10,.15,.20,.30,.40,.50,.60,.70,.80,.90,.95,.99,.995,.999\}$ bits. Capacity grids are ASSISTments $\{100,250,500,1000,2000\}$, OULAD $\{50,100,200,500,1000\}$ and synthetic $\{20,50,100,200,300\}$. Each full grid has 80 candidates. Fixed-budget recovery uses only the 16 thresholds at $K=1000,500,100$, respectively. Full-grid profile comparisons are reported separately. We check gap $\leq.05$ and automation coverage $\geq.50$ and apply the algorithm in Section~\ref{sec:method}.

\subsection{Exploratory contestation study}
\label{sec:human-study}
The original study has 16 volunteers, eight standardized appeal scenarios and 64 case responses per condition. Profiles include engineering/data science, analytics and audit/compliance. Each participant responds to four cases under A (logs/cards) and four under B (structured per-case evidence, policy provenance and replay narratives). The author confirmed that G1 receives odd cases in A and even cases in B, with G2 reversed. Each case therefore has eight responses per condition. No participant sees the same case in both conditions. Detailed recruitment procedures, compensation and training records were not available in the inspected release.

For each case, participants choose a diagnostic label and remediation action, cite evidence, and rate confidence from 1 to 5. Evidence length is counted in Unicode characters, not words or a quality rubric. Time was self-reported for the questionnaire; we do not estimate per-case staff savings. The case materials include hypothetical exceptions and feature changes beyond the fixed-score replay engine. Consequently this study evaluates availability of structured evidence as a bundle, not execution of every scenario by the software or the isolated causal effect of replay.

\paragraph{Consent and ethics reporting.}
The author confirmed voluntary participation and authorization. The forms contain a consent item. No formal ethics-committee approval or exemption was obtained; we report this explicitly rather than infer an institutional authorization. No participant-level responses or free-text evidence are redistributed in the revised public analysis outputs. The setting and documentation limit the strength and generalizability of the study.

\paragraph{Retrospective analysis.}
We recompute participant-level condition averages from the original CSVs and case gabarits. The revision uses two-sided signed-rank tests by enumerating all sign assignments to nonzero paired midranks; zero differences are excluded and equal absolute differences receive average ranks. No normal approximation or continuity correction is used. Holm adjustment covers diagnosis, remediation, confidence and evidence length. Paired mean differences have percentile 95\% intervals from 10000 participant-bootstrap replicates (seed 42). This analysis was specified after inspecting historical results and is not preregistered. Diagnosis and remediation correctness coincide on all 128 case responses and are not independent replications. Software versions and exact counts are recorded with the released revision scripts.
''')
write('sections/06_results.tex',r'''
\section{Results}
\label{sec:results}
We distinguish historical emitted decisions from the revised implementation and reanalysis. All numerical tables below are generated from the preserved packets or study responses; no historical predictor was retrained.

\subsection{Structured evidence in the exploratory study}
\label{sec:human-results}
Table~\ref{tab:human-study-summary} reports recomputed averages, paired effects and revised statistical tests. Diagnostic and remediation accuracy increase from 0.5625 to 0.921875, a difference of 0.359375. Confidence increases from 3.078125 to 4.234375. These aggregates match the historical data; revised p-values differ because a single bilateral procedure and multiplicity correction replace the previously underspecified tests. Longer evidence statements are descriptive and do not establish better reasoning. The experiment supports a benefit of the complete evidence bundle on these standardized tasks, with the limitations in Section~\ref{sec:human-study}.
\input{tables/human_study_summary}
\input{tables/human_study_keycases}
\begin{figure}[t]
\centering
\includegraphics[width=\linewidth]{figures/human_label_accuracy_by_case.png}
\caption{Diagnostic accuracy by case and condition. Labels give exact correct/total counts; all bars have eight responses.}
\Description{Grouped bars compare baseline A and structured-evidence B across eight appeal cases. B equals A in C4 and is higher in the other seven cases. Exact numerators and denominators appear in the adjacent case-count table.}
\label{fig:human-by-case}
\end{figure}

\subsection{Historical states and capacity}
Table~\ref{tab:run-initial} recomputes the historical recipe outcomes and Table~\ref{tab:state-counts} gives exact counts. In the synthetic example $K=100$ but only four cases are eligible and selected; coverage 0.004 is therefore consistent with the capacity ceiling. OULAD similarly selects 69 of a possible 500. Violations were recorded by the historical runner; those records alone do not prove operational escalation.
\input{tables/run_initial}
\input{tables/state_counts}

\subsection{Fixed-budget recovery and variable-budget profiles}
Table~\ref{tab:run-sweep} separates full-grid and fixed-budget counts. Table~\ref{tab:recovered} reports achieved metrics of the revised fixed-budget MAS choices. Raising $\gamma$ recovers sample feasibility without retraining, demonstrating a policy-level route to resolve the particular violation. This does not exclude simultaneous model or measurement problems. Table~\ref{tab:policy-profiles} reports separate variable-budget comparisons with the complete profile definitions in Section~\ref{sec:method}. Full precision, group counts, exact grids and candidate IDs are in the structured revision report.
\input{tables/run_sweep_summary}
\input{tables/recovered_metrics}
\input{tables/policy_profile_tradeoffs}

\subsection{Taxonomy and uncertainty}
Table~\ref{tab:policy-replay} fixes scores, $K$ and $\gamma$ while changing abstention semantics. Utility stays fixed in this example, but automation coverage changes because non-selection can be an automated rejection or a deferral. Treating this as a policy correction requires institutional justification; the numbers alone cannot establish which responsibility assignment is appropriate.
\input{tables/policy_replay}

Table~\ref{tab:uncertainty_proxy_validation} incorporates the previously disconnected numerical validation, recalculated with one entropy convention and average ranks for ties. OULAD has lower entropy/error monotonicity than ASSISTments; the synthetic predictor is poorly calibrated. Temperature scaling can worsen ECE, so we do not claim calibration robustness from preserved rank correlation. The report includes conditional row-bootstrap intervals and group-specific error counts and Wilson intervals across thresholds. Historical interaction packets lack student cluster IDs, so the ASSISTments intervals do not establish cluster-robust uncertainty or field reliability.
\input{tables/uncertainty_proxy_validation}

\subsection{Artifact checks and appeal scope}
The historical four-point scorecard was populated by constant booleans in the runner, so it is not evidence of independent artifact validation. The revised verifier instead computes integrity and decision-reconstruction checks and tests failures after packet tampering or missing policy content. Fitted-model hashes are separated from configuration hashes; the earlier configuration-only digest is not presented as an immutable trained-model identity.

The appeal pack (Table~\ref{tab:appeal_scenarios}) is a set of study materials. Medical exceptions, changing income, or removing a feature require additional policy inputs or re-scoring and are outside the fixed-score replay contract. Evidence strings in these materials are not execution logs proving that the released engine implements those operations.
\input{tables/appeal_scenarios}
''')
write('sections/07_discussion.tex',r'''
\section{Discussion and Limitations}
\label{sec:discussion}
\subsection{Institutional value and responsibility}
An audit trail makes choices inspectable, but does not make the choices legitimate by itself. Constraints are set by actors with authority and incentives; versioning can expose changes but cannot prevent capture or selective compliance \cite{Selbst2019Abstraction,Metcalf2021AIA}. Institutions still need accessible appeal channels, a mandate for policy changes, appropriate staffing and a way to reverse or remedy decisions. A deployment should record who changed a policy, why, who may contest it and how resulting cases are handled.

Automation coverage measures automated outcomes, including rejection. It must not be equated with access to support or students helped. In screening mode the coverage floor can conflict structurally with limited K; increasing automation by relabeling cases changes the division of responsibility between software and staff. Our experiments expose that choice rather than endorse one taxonomy universally.

\subsection{What the evidence establishes}
The strongest evidence is computational: rules can be made explicit, decisions can be replayed on fixed scores, infeasibility can be surfaced, and revised exports can be gated. Sample-level constraints are not population guarantees. Policy selection on the same labelled audit set is exploratory. One historical model and split per dataset do not establish multi-seed predictive stability, comparative state of the art or educational treatment benefit.

The N=16 study is exploratory, uses author-defined standardized scenarios and mixed technical profiles, and has incomplete recruitment and training documentation. Volunteers and consent do not substitute for a formal ethics review, which was not obtained. No causal separation among provenance, structured information and replay is possible in its two conditions. Diagnosis and remediation correctness are perfectly concordant in these responses, so the study provides fewer independent outcome dimensions than its labels might suggest. A prospective study with independent cases, frontline stakeholders and documented institutional review is needed before making field claims.

\subsection{Uncertainty and data limitations}
Predictive entropy is a scalar confidence proxy, not a decomposition of epistemic and aleatoric uncertainty. Calibration and entropy/error correlation do not alone validate the safety of deferral. We therefore provide group-level selective-error summaries and explicitly conditional intervals. ASSISTments uses school-ID parity only to stress the constraint machinery; it does not measure protected-group disparities. OULAD uses binary gender and success labels, leaving wider intersectional and measurement questions unresolved \cite{BakerHawn2022AlgorithmicBiasEducation}.

\subsection{Privacy, integrity and operational boundaries}
Packets must contain the inputs required for the supported rule, with purpose-appropriate access and retention controls. Publishing medical information or raw feature histories is not required by our minimum contract. An institution can keep restricted source evidence behind resolvable references, but missing evidence must be reported rather than treated as replay success. Hashes establish consistency of bytes, not external authenticity or truth. The revised runner's review-required file is not a connected case-management process.

We make no automatic legal-compliance claim. A particular deployment requires jurisdiction-specific institutional review. Instrumented per-case audit cost, staffing capacity, actual access to appeal, independent prospective evaluation and model re-scoring under corrected inputs remain future work. Changing a feature or target creates a new inference or modeling task and must not be described as a policy-only replay.
''')
write('sections/08_conclusion.tex',r'''
\section{Conclusion}
\label{sec:conclusion}
We present an artifact-oriented approach to educational decision-system governance: explicit policy, empirical constraints, deterministic feasible-Pareto selection and fixed-score replay. The revision reconciles definitions, identifies the actual outcome-prediction tasks, specifies entropy in bits and capacity ceilings, and separates historical violation reporting from the revised export gate. Computational reports expose policy-dependent feasibility and the consequences of decision taxonomy without implying improved student outcomes.

An exploratory N=16 study supports the complete structured-evidence bundle for standardized appeal diagnosis, with revised statistical reporting and explicit ethical and methodological limits. It does not validate every hypothetical exception, isolate replay from information availability or establish institutional recourse. Future work requires prospective stakeholder evaluation, documented ethical review, independent policy validation, richer uncertainty methods and an instrumented human workflow. Code, exact counts and revision analyses are identified in Appendix~\ref{app:repro}; distribution of participant responses is separate from distribution of aggregate results.

\subsection*{Acknowledgments}
We thank the volunteers and colleagues who contributed to the exploratory evaluation.
''')
write('tables/claim_evidence_map.tex',r'''
\begin{table*}[t]
\centering\small
\caption{Claims, evidence and explicit boundaries of the revised manuscript.}
\label{tab:claim_evidence}
\begin{tabularx}{\textwidth}{p{.20\textwidth}XX}
\toprule
Claim & Evidence & Boundary \\
\midrule
Fixed-score replay & State reconciliation and taxonomy replay, Tables~\ref{tab:state-counts} and~\ref{tab:policy-replay} & Does not support changed features or medical exceptions. \\
Empirical selection & Algorithm~\ref{alg:mas}, Tables~\ref{tab:run-sweep} and~\ref{tab:recovered} & Same-sample policy exploration; no population fairness guarantee. \\
Explicit failure & Revised runner gate and integration tests, Section~\ref{sec:design} & Historical violation logging was not operational fail-closed; no human queue connected. \\
Structured evidence benefit & Tables~\ref{tab:human-study-summary} and~\ref{tab:human-study-keycases} & Exploratory N=16, no formal ethics review; bundle effect, not isolated replay effect. \\
Entropy diagnostics & Table~\ref{tab:uncertainty_proxy_validation} and structured group-risk report & Scalar proxy; conditional row intervals, not cluster-robust field validation. \\
\bottomrule
\end{tabularx}
\end{table*}
''')
write('appendices/appendix_B.tex',r'''
\section{Implementation and Version-Specific Inventory}
\label{app:implementation}
The historical release contains one scored run per dataset, metrics, metadata, decision briefs and case packets. Sweeps and illustrative appeal materials exist in the paper project, and original N=16 responses are available locally to the author. The previous statement that the release lacked sweeps and human evaluation was inconsistent with these materials and has been removed. The study AIES N=18 is a different version and is not used here.

The revised application is in the repository directory named \texttt{compass-contestable-governance-artifacts}. New runs persist policy content, a dataset-manifest copy, fitted-model bytes, separate configuration/model hashes, source-file hashes, selection reports, candidate packets, computed artifact checks and an authorization gate. A Git HEAD alone does not identify uncommitted source changes. Model snapshots are hashed as opaque bytes; verifying integrity does not require loading untrusted serialized code.

A feasible run may export authorized candidate decisions. Infeasible or insufficient-evidence runs preserve evaluation evidence and write a review-required record without an authorized export. They do not claim delivery to a human queue. Candidate metrics remain distinguishable from the gate result.

No broad predictive-baseline study, multi-seed model evaluation, field deployment or individually timed appeal-cost study is claimed. Historical outputs are preserved; revision reports identify which values match and which procedures changed.
''')
write('appendices/appendix_C.tex',r'''
\section{Prospective Early-Warning Blueprint: Not Evaluated Here}
\label{app:replication}
A future dropout-prevention use would define a risk-positive outcome, such as Fail/Withdrawn, an intervention horizon, features available before that horizon, and ranking aligned to that objective. It would also require temporal and student-aware splits, label audits and institutionally justified sensitive attributes. These choices differ from the implemented OULAD success target and descending success-score ranking. The current utility values must not be reused as evidence for this proposed task.

Likewise, interaction correctness in ASSISTments is not equivalent to a per-student need-for-support label. Aggregating interactions, selecting an eligible population, specifying the treatment and measuring actual benefit require a separate evaluation. Changing the target or removing features can require retraining; changing an input value requires new inference. Neither operation is a fixed-score policy replay.
''')
p=P/'appendices/appendix_D.tex';s=p.read_text();s=s.replace('In real early-warning deployments, temporally aware splits should be used to avoid leakage; we treat this as future work.','These shuffled interaction splits do not establish temporal or student-cluster separation. No early-warning validation or cluster-robust generalization is claimed.').replace('For policy governance, the key requirement is that the resulting dataset manifest and split seed are recorded so that runs are replayable.','Recorded snapshots and seeds support reproducibility, but not prospective policy validation; the same audit scores and labels are used for policy exploration.');p.write_text(s)
write('appendices/appendix_E.tex',r'''
\section{Artifact Contract and Replay Protocol}
\label{app:artifact-schema}
\subsection{Minimum fixed-score contract}
Schema 2.0 records a persistent case ID, finite score, entropy in bits, clipping convention, decision state, supported replay scope, policy reference/hash, dataset-manifest hash, fitted-model hash and packet hash. Policy content records capacity, score direction, allocation/screening mode, global/Top-$K$-only abstention, threshold/unit and selection criteria/tolerances. Hashes alone are not substitutes for accessible policy content. Labels and audit groups are evaluation fields, separate from decision inputs.

Historical packets have a smaller unversioned schema. Their entropy is checked against the known bit-based implementation before reanalysis; a legacy configuration digest is not described as a fitted-model digest. The revision does not retroactively claim that old packets implemented schema 2.0.

\subsection{Reconstruction and validation}
Replay reads the same fixed scores and case IDs, applies the declared rule and compares every emitted state with the original. The revised verifier additionally checks content hashes, schema/unit fields, policy availability, manifest bytes and model-snapshot bytes. Missing, altered or incompatible evidence causes failure, not a perfect score by default. Tests include score ties, reordered inputs, boundary thresholds, empty feasible sets and corrupted packets.

\subsection{Scope of appeal materials}
Medical-force-inclusion rules require the applicable rule, its version, the relevant flag and exception precedence. These are absent from the minimum score-based contract; no executed medical-exception replay is claimed. Likewise, income corrections or feature removal require updated inputs and re-scoring, possibly retraining. The study's evidence strings are scenario materials rather than logs proving these operations were executed. Restricted evidence may remain outside public bundles, but its availability and access conditions must be documented.

\subsection{Uncertainty analysis}
\label{app:uncertainty}
ECE uses ten equal-width probability bins, including probability one in the final bin. Spearman entropy/absolute-error correlation uses average ranks for ties. Temperature stress uses logits scaled by $T\in\{0.5,2\}$ and recomputes entropy in bits. Conditional percentile intervals use 200 row-bootstrap replicates, seed 42. Per-group selective risk is the binary classification error among entropy-eligible cases, not precision among Top-$K$ selections; reports give error counts, denominators and descriptive Wilson intervals. Interaction packets do not preserve student cluster IDs, so these row-based intervals do not establish cluster-robust population uncertainty.
''')
write('appendices/appendix_A.tex',r'''
\section{Reproducibility and Revision Evidence}
\label{app:repro}
The revision preserves the historical sources and numerical assets in a checksum-indexed snapshot. A version inventory and work log are maintained in the accompanying \texttt{revisao\_artigo} directory. The reference repository is \CompassRepoURL; local revised code and hashes, rather than the unmodified remote HEAD, identify the changes evaluated here.

The historical packet runs used are ASSISTments (20260126T031036Z), OULAD (20260126T031033Z) and synthetic (20260126T234652Z), all seed 42. Their full paths and SHA-256 digests appear in the computational revision report. No new fit of those historical models is claimed.

\paragraph{Rebuilding the analysis.}
From the project root, the script \path{revisao_artigo/scripts/recalcular_evidencias.py} regenerates computational reports, candidate tables, group-risk summaries, study aggregates and the English diagnostic figure. It uses the preserved case packets and, for the study, the author's local response ZIP. The author confirmed the original assignment mapping in this revision. Outputs are in \path{paper_assets/revised/}. Individual response text is not copied to those outputs.

The report records complete thresholds, capacities, IDs, counts and comparisons with historical CSVs. Fixed-budget and full-grid results have separate domains. Script source and an environment lock accompany the revision. Application tests include a synthetic end-to-end run and corruption checks; they do not substitute for re-fitting real-data predictors.

\paragraph{Access limitations.}
Historical packet labels and audit groups are retrospective evaluation data. Participant responses remain local in this revision; sharing consent and institutional rules must be checked before redistribution. Aggregate counts and scripts are included. A computational reproduction can run without the study data and must report the study as skipped, never silently substitute generated participants. The revised study analysis was retrospective, not preregistered.

\paragraph{Compilation and verification.}
The multi-file LaTeX project is compiled with Tectonic, with its release recorded in the revision tools inventory. Generated tables use unrounded metrics and round only for display. All rendered pages are inspected for clipping and broken references. Source snapshots, checksums, software versions and verification records distinguish the historical release from this corrected draft.
''')
# Correct the verified bibliographic record.
p=P/'references/references.bib';s=p.read_text();s=re.sub(r'@inproceedings\{Alfrink2023ContestableAI,.*?\n\}',r'''@article{Alfrink2023ContestableAI,
 author = {Alfrink, Kars and Keller, Ianus and Kortuem, Gerd and Doorn, Neelke},
 title = {Contestable {AI} by Design: Towards a Framework},
 journal = {Minds and Machines},
 volume = {33},
 pages = {613--639},
 year = {2023},
 doi = {10.1007/s11023-022-09611-z}
}''',s,flags=re.S);p.write_text(s)
# Do not present a capability survey as exhaustive empirical comparison.
write('tables/positioning.tex',r'''
\begin{table*}[t]
\centering\small
\caption{Roles of related approaches; this conceptual positioning is not an exhaustive capability audit of all implementations.}
\label{tab:positioning}
\begin{tabularx}{\textwidth}{lXX}
\toprule
Approach & Main role & Relationship to this work \\
\midrule
Ethical principles & State institutional commitments & Motivate requirements, without fixing our schema. \\
Fairness toolkits & Measure or mitigate group disparities & Complement empirical ECL checks. \\
Impact assessments & Document impacts and responsibilities & Complement policy rationale and review procedures. \\
Contestability by design & Keep systems open to intervention & Motivates preserved case evidence and bounded replay. \\
COMPASS revision & Fixed-score policy audit and artifacts & Demonstrates explicit rules, reconstructed states and export gating. \\
\bottomrule
\end{tabularx}
\end{table*}
''')
# Appeal materials keep historical narratives but fit columns and label scope.
p=P/'tables/appeal_scenarios.tex';s=p.read_text().replace(r'\textbf{Appeal pack used in the task-based contestation study (8 cases).}',r'\textbf{Illustrative study materials (8 cases); not execution logs for every rule.}')
s=s.replace(r'\small',r'\scriptsize').replace(r'p{0.06\textwidth}p{0.16\textwidth}p{0.26\textwidth}X X',r'p{0.035\textwidth}p{0.16\textwidth}p{0.23\textwidth}X X')
s=s.replace(r'\texttt{ABSTENTION\_ROUTING\_ERROR}',r'Abstention routing').replace(r'\texttt{PROXY\_DISCRIMINATION\_RISK}',r'Proxy risk').replace(r'\texttt{VERSION\_MISMATCH\_DRIFT}',r'Version mismatch').replace(r'\texttt{CAPACITY\_CONSTRAINT}',r'Capacity').replace(r'\texttt{NORMATIVE\_EXCEPTION}',r'Exception').replace(r'\texttt{FAIRNESS\_BINDING}',r'Fairness').replace(r'\texttt{POLICY\_CHANGE}',r'Policy change').replace(r'\texttt{DATA\_ERROR}',r'Data error')
# Translate summaries that previously mixed Portuguese and English.
for a,b in {'logs/scores padrão; sem referência à regra/portaria':'logs/scores; no exception rule reference','score=0.76, mas não selecionado':'score=0.76; not selected','lista do Top-K evidencia inversão de score':'Top-K list shows score inversion','features incluem zipcode/school\_zone/distance':'features include ZIP code, school zone, distance','baseline não expõe métrica de incerteza nem threshold de abstenção':'baseline lacks uncertainty and abstention threshold','justificativa textual menciona v2.1':'text cites v2.1','esperado abstain=true':'expected abstain=true','policy\_version declarada v2.1, mas executou policy\_bundle=v2.0 (hash mismatch)':'declared v2.1; executed v2.0 (hash mismatch)','zipcode correlaciona com atributo sensível (indicador externo)':'ZIP code correlates with audit group (external indicator)'}.items():s=s.replace(a,b)
p.write_text(s)
print('Scientific text revised; generated evidence tables remain script-controlled.')
