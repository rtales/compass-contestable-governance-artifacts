"""Persistent final checks: app tests are run separately; no individual data exported."""
from pathlib import Path
import os,sys,json,subprocess,hashlib,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2];P=ROOT/'Governing_by_Artifacts__An_Auditable_Constraint_Based_Framework_for_Contestable_Educational_Decision_Systems';APP=ROOT/'compass_github/compass-contestable-governance-artifacts';EV=ROOT/'revisao_artigo/evidencias'
sys.path.insert(0,str(APP/'src'))
import yaml
from compass.pipeline.run import run_recipe
from compass.artifacts.validation import verify_run

recipe=yaml.safe_load((APP/'configs/recipes/synthetic.yaml').read_text())
recipe['dataset']['local_path']=str(APP/'data/synthetic_v1/processed')
recipe['outputs']={'root':str(EV/'execucoes_corrigidas'),'decision_brief':False,'bundle_zip':False,'decision_packets':True}
recipe['policy']['ecl']['constraints']={'max_delta_eopp_at_k':1,'min_coverage':0}
recipe['policy']['mas']['grid']={'k':[20,100],'gamma_entropy':[.65,1.]}
runs={}
for state,floor in [('feasible',0),('infeasible',1)]:
 r=json.loads(json.dumps(recipe))
 if state=='infeasible':
  r['policy']['abstain']['gamma_entropy']=.65;r['policy']['mas'].pop('grid',None)
 r['policy']['ecl']['constraints']['min_coverage']=floor
 file=EV/f'smoke_{state}.yaml';file.write_text(yaml.safe_dump(r))
 run=run_recipe(file);checks=verify_run(run);gate=json.loads((run/'deployment_gate.json').read_text())
 assert checks['score']==4
 assert gate['deployment_authorized']==(state=='feasible')
 assert (run/'authorized_decisions.json').exists()==(state=='feasible')
 runs[state]={'path':str(run.relative_to(ROOT)),'checks':checks,'gate':gate}

# Check active LaTeX references against included sources only.
import re
active=[]
def visit(path):
 text=re.sub(r'(?<!\\)%[^\n]*', '', path.read_text());active.append((path,text))
 for include in re.findall(r'\\input\{([^}]+)\}',text):
  target=P/(include+'.tex')
  assert target.exists(),target
  visit(target)
visit(P/'main.tex')
labels=[];refs=[]
for f,text in active:
 labels.extend(re.findall(r'\\label\{([^}]+)\}',text))
 for refgroup in re.findall(r'\\(?:ref|Cref)\{([^}]+)\}',text):refs.extend(refgroup.split(','))
assert len(labels)==len(set(labels)),'Duplicate labels'
assert not set(refs)-set(labels),set(refs)-set(labels)
assert '\\input{tables/uncertainty_proxy_validation}' in (P/'sections/06_results.tex').read_text()
# Compare generated table cells with structured values, not rounded complements.
report=json.loads((P/'paper_assets/revised/computational_report.json').read_text())
for name,item in report.items():
 assert item['initial_decision_mismatches']==0
 assert len(item['grid']['k'])*len(item['grid']['gamma_bits'])==80
 assert item['fixed_k']['n_candidates']==16
 for key in ['utility_at_k','coverage','abstain_rate','abs_delta_eopp_at_k','n_selected','n_non_abstain']:
  assert item['max_difference_from_historical_csv'][key]<1e-12
  assert item['max_difference_from_historical_csv'][key+'_undefined_mismatch_count']==0
study=json.loads((P/'paper_assets/revised/study_report.json').read_text())
assert study['diagnosis_remediation_agreement']==128 and study['n_per_condition']==64
assert abs(study['outcomes']['diagnosis']['difference']-.359375)<1e-12
assert 'medical' in (P/'appendices/appendix_E.tex').read_text().lower()

result={'synthetic_runs':runs,'latex_included_files':len(active),'latex_labels':len(labels),
        'undefined_refs':[],'historical_state_mismatches':{name:r['initial_decision_mismatches'] for name,r in report.items()},
        'legacy_grid_comparison':'all finite differences <1e-12; undefined patterns identical',
        'study_n':16,'individual_responses_exported':False}
(EV/'validacao_integrada.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
