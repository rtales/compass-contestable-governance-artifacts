"""Build a portable review bundle without participant responses or private raw data."""
from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parents[2];REV=ROOT/'revisao_artigo';P=ROOT/'Governing_by_Artifacts__An_Auditable_Constraint_Based_Framework_for_Contestable_Educational_Decision_Systems';APP=ROOT/'compass_github/compass-contestable-governance-artifacts';EV=REV/'evidencias'
files=set()
def add_tree(folder,suffixes):
 for f in folder.rglob('*'):
  if f.is_file() and f.suffix in suffixes and not any(x in f.parts for x in ['.git','__pycache__']):files.add(f)
for folder in ['src','tests','configs','snapshots','paper_template','docs']:add_tree(APP/folder,{'.py','.yaml','.json','.md','.tex'})
add_tree(APP/'data/synthetic_v1',{'.csv','.npz','.npy','.json'})
for name in ['pyproject.toml','README.md']:files.add(APP/name)
for folder in ['sections','appendices','tables','references','paper_assets','code']:add_tree(P/folder,{'.tex','.bib','.json','.csv','.yaml','.md','.py','.txt'})
for name in ['main.tex','README.md','README_reproduce.md','SUBMISSION_CHECKLIST.md','reproduce.sh']:files.add(P/name)
files.add(P/'figures/human_label_accuracy_by_case.png')
add_tree(REV/'scripts',{'.py'})
files.update(REV.glob('*.md'))
# Exclude the virtualenv and caches from the previous broad Markdown addition.
files={f for f in files if not (f.is_relative_to(REV) and any(x in f.relative_to(REV).parts for x in ['ambiente','cache','ferramentas']))}
files.add(REV/'requirements.lock')
report=json.loads((P/'paper_assets/revised/computational_report.json').read_text())
for value in report.values():
 packet=ROOT/value['packet_path'];files.add(packet)
 for name in ['run_metadata.json','metrics.json','reports/decision_brief.json']:
  f=packet.parent.parent/name
  if f.exists():files.add(f)
validation=json.loads((EV/'validacao_integrada.json').read_text())
for value in validation['synthetic_runs'].values():add_tree(ROOT/value['path'],{'.json','.jsonl','.pkl'})
files.add(REV/'ferramentas/tectonic_origem.json')
for name in ['validacao_integrada.json','testes_aplicacao.xml','testes_pacote_limpo.xml','reproducao_pacote.json','alteracoes_fontes.json','compilacao_revisada.log']:
 if (EV/name).exists():files.add(EV/name)
if (EV/'artigo_revisado.pdf').exists():files.add(EV/'artigo_revisado.pdf')
manifest=[{'path':str(f.relative_to(ROOT)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in sorted(files)]
# Source snapshot ID is independent of the ZIP container's timestamps.
identity=hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()
manifest_path=EV/'manifesto_revisao_final.json'
manifest_path.write_text(json.dumps({'snapshot_id':identity,'files':manifest,'participant_responses_included':False},indent=2)+'\n')
archive=EV/'pacote_revisao.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(files):z.write(f,str(f.relative_to(ROOT)))
 z.write(manifest_path,str(manifest_path.relative_to(ROOT)))
sha=hashlib.sha256(archive.read_bytes()).hexdigest();(EV/'pacote_revisao.sha256').write_text(sha+'  pacote_revisao.zip\n')
print(json.dumps({'snapshot_id':identity,'files':len(files),'zip_bytes':archive.stat().st_size,'zip_sha256':sha},indent=2))
