# Especificação científica da revisão

## Escopo adotado

Preservar tarefas históricas: ASSISTments prevê correção (1=correto), OULAD prevê sucesso (1=Pass/Distinction). Score é probabilidade estimada da classe positiva, com ranking descendente. Utility@K é precisão entre selecionados. Nenhum desses experimentos é apresentado como validação de priorização de estudantes com maior risco ou efeito de intervenção.

O blueprint de alerta precoce é proposta futura e exige alvo de risco, janela temporal, split por aluno/tempo e reavaliação. Não basta inverter sinais nas tabelas.

## Decisão e métricas

Entropia binária em bits; epsilon=1e-7 para clipping em float64; máximo 1. Comparação estrita u>gamma gera abstenção. Limiares variam de 0 a 1. K é limite não negativo; selecionados podem ser menos que K. Allocation: elegíveis não selecionados são reject. Screening: todos não selecionados são abstain. Abstenção global precede ranking dos elegíveis; abstenção topk afeta apenas os indicados pelo ranking global e não preenche vagas de abstidos.

Taxa de seleção = select/n. Cobertura automatizada = (select+reject)/n = 1-abstain/n. Elegibilidade pode diferir da cobertura no screening. Screening implica cobertura <= K/n. Revisão humana é necessidade registrada; a aplicação não possui fila humana conectada.

IDs de caso são persistidos e usados no desempate; nos novos runs correspondem à linha do snapshot com prefixo do dataset. A estabilidade é dentro do mesmo snapshot, não entre snapshots sem mapeamento.

Equidade é diferença absoluta entre TPRs para selecionar, com denominadores positivos por grupo em todo o conjunto auditado. Grupo sem positivos ou menos de dois grupos gera evidência insuficiente, não gap zero. Seleção vazia tem utilidade indefinida. Os labels são retrospectivos e não requisitos para reconstruir decisões futuras.

## Seleção de políticas

Primeiro restrições empíricas (gap<=0.05, cobertura>=0.50 nas grades do artigo), depois Pareto exato (max utilidade, min gap, min abstenção), depois prioridades lexicográficas e ID de candidato. Tolerância por critério = 0 na análise revisada. O estado vazio é inviável e fecha a autorização de exportação. Igualdade de métricas preserva candidatos equivalentes na fronteira; o ID resolve o desempate final.

Grades históricas: 5 valores de K x 16 gamma. Análise de recuperação usa somente os 16 pontos no K da recipe. Perfis variáveis usam todos os 80. A recipe sintética histórica tinha cobertura mínima 0.60; a análise comparável usa 0.50. Isso é registrado como mudança de política, sem atribuí-la retrospectivamente à recipe.

## Artefatos e limites

Schema 2.0 suporta scores fixos e regras Top-K/abstenção declaradas. Dados de entrada alterados exigem nova inferência. Exceções médicas e regras por feature são cenários ilustrativos fora desse contrato. Hashes verificam consistência com bytes, não verdade, justiça ou autenticidade externa.

Os modelos ajustados e a configuração têm hashes separados. A verificação de artefatos nunca desserializa pickle não confiável. O runner registra revisão Git e hashes dos fontes atuais, pois HEAD isolado não representa alterações locais.

## Estudo humano

N=16, oito casos; 64 respostas por condição. Atribuição confirmada pelo autor. Participação voluntária; autorização informada pelo autor; sem aprovação/dispensa formal de comitê. A revisão não publica dados individuais. Análise retrospectiva bilateral de postos com enumeração de sinais, zeros removidos e ranks médios para empates; Holm em quatro desfechos; IC por bootstrap de participantes. Diagnóstico e remediação coincidem e não são evidências independentes.
