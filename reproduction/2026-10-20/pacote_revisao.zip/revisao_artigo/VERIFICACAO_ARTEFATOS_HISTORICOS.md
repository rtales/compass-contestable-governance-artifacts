# Verificação adicional dos artefatos históricos

Estes checks não são o scorecard v2. Os modelos ajustados originais não estão armazenados nos runs; não se atribui a eles a verificação v2.

| Dataset | Hashes de pacotes corretos | Política do brief confere hash do run | Estados originais reconstruídos |
|---|---:|---|---|
| assistments | 105107/105107 | True | True |
| oulad | 6519/6519 | True | True |
| synthetic | 1000/1000 | True | True |
