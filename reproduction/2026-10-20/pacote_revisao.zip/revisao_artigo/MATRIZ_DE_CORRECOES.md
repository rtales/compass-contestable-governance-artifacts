# Matriz de correções

Estado inicial em 2026-10-20: diagnóstico. A execução autorizada e seus estados finais estão registrados ao final deste documento.

O número O corresponde à lista de 12 observações fornecida pelo autor. A numeração de tabelas pode mudar entre versões; rastrear também pelo label LaTeX.

| ID | Diagnóstico atual | Ação no texto | Ação no código/dados | Evidência necessária | Etapas |
|---|---|---|---|---|---|
| O01 | Blueprint de risco e implementação de sucesso coexistem no original | Separar tarefa executada de proposta de alerta precoce; explicar utilidade | Validar label, ranking e unidade; nova recipe se mudar tarefa | Teste com casos de sucesso/fracasso conhecidos e rastreio do alvo | 1, 2, 6, 9 |
| O02 | Pipeline usa bits; script auxiliar recalcula entropia com log natural | Definir fórmula, unidade, clipping e gamma | Função compartilhada e schema com unidade | Pacotes conferidos; gamma=0.999 não implica cobertura 1 em bits | 3, 6, 7 |
| O03 | Pseudocódigo omite Pareto; script de estabilidade o executa; integração do runner insuficiente | Pseudocódigo fiel ao fluxo final | Viabilidade/Pareto/MAS, tolerâncias, IDs e conjunto vazio | Testes de dominância, empate e invariância à ordem | 4, 9 |
| O04 | Relato humano incompleto; isso não prova ausência de procedimentos | Completar fatos verificáveis ou declarar limitações | Inventariar documentos de recrutamento/consentimento/ética/compensação | Documentação do estudo N=16, sem transportar o protocolo N=18 | 8, 9 |
| O05 | Agregados conferem sob mapeamento A/B compatível; testes dependem de configurações | Informar unidade, efeitos, intervalos e multiplicidade | Script por participante e validação de gabarito/mapeamento | Recomputação e documentação exata de zeros/empates/método | 8 |
| O06 | Imagem original tem português | Traduzir e adicionar descrição acessível | Gerar figura de contagens e dados rastreáveis | Acertos e denominadores por condição/caso | 8, 10 |
| O07 | K é limite; sintético original tem 4 selecionados, 996 abstenções | Reportar estados e denominadores; corrigir notação de cobertura | Contagens inteiras por estado e grupo; K efetivo e elegíveis | Recomputação sobre pacotes identificados | 2, 3, 6 |
| O08 | Grade real 5×16; narrativa mistura K fixo e variável | Descrever análises e perfis separadamente | Persistir grids, subconjuntos, objetivos, tolerâncias e escolhas | 80 pontos por grade histórica e contagens próprias por subconjunto | 4, 6, 9 |
| O09 | Tabela 11 não está cortada no PDF original inspecionado; DOCX ausente | Atribuir defeito somente à versão em que for observado | Gerar células de métricas exatas, sem reconstrução por arredondamento | QA visual por versão e conferência numérica | 1, 6, 10 |
| O10 | Schema mínimo não sustenta regras de exceção nem re-scoring | Limitar replay a escopo comprovado; qualificar casos ilustrativos | Schema completo para regras implementadas ou retirada da promessa | Replay contra original, falha por insumo ausente e casos de exceção | 5, 9 |
| O11 | Apêndice B e checklist contradizem resultados e artefatos | Inventário por versão; remover negativas obsoletas | Manifesto, revisão imutável, scripts e outputs permitidos | Execução limpa do bundle e mapa resultado→fonte | 1, 8, 9, 11 |
| O12 | ECE/correlação existem em arquivos, mas tabela não está incluída no build | Incorporar resultados efetivos e limites da proxy | Recalcular com definição única, empates e incerteza/grupos | Relatórios, tabela incluída, risco seletivo e intervalos | 7, 9 |

## Achados adicionais que entram no mesmo plano

| ID | Risco observado | Correção planejada | Critério de conclusão |
|---|---|---|---|
| A01 | Notação usa seleção/n como cobertura; método usa (seleção+rejeição)/n | Separar taxa de seleção e cobertura automatizada | Definições iguais em código, tabelas, notação e apêndices |
| A02 | Runner inspecionado registra violações ECL, mas continua emitindo decisões candidatas | Separar avaliação de autorização e impedir saída implantável inviável | Teste de ponta a ponta comprova bloqueio ou artigo reduz alegação |
| A03 | Scorecard é instanciado com quatro booleanos verdadeiros | Calcular verificações reais | Remoção/corrupção de artefato muda resultado e impede replay |
| A04 | `model_hash` deriva da configuração, não do modelo treinado | Distinguir hashes e persistir artefato/preprocessing | Mudança de parâmetros ajustados altera hash do modelo |
| A05 | `*_selected.json` e `*_mas_selection.json` diferem em gamma | Identificar perfis/execuções e regenerar saídas com IDs | Nenhuma escolha reportada tem origem ambígua |
| A06 | Aplicação usa ordenação NumPy; replay usa pandas, com semânticas potenciais de empate diferentes | Regra única de ranking e ID estável | Mesmos insumos produzem mesmas decisões, inclusive com empate |
| A07 | Exemplos de mudar renda/remover CEP exigem re-scoring | Separar replay de política e nova inferência | Cada cenário classificado e executado somente sob contrato compatível |
| A08 | Métricas de equidade usam labels futuros; garantias podem parecer de produção | Explicitar auditoria retrospectiva e condições de generalização | Nenhuma promessa operacional exige y indisponível no instante da decisão |
| A09 | Correlação auxiliar usa ranks ordinais sem tratamento médio dos empates | Usar implementação estatística documentada e testes com empates | Comparação com valores de referência e reporte de diferenças |

## Estados para atualização

`diagnosticado` → `especificado` → `implementado` → `recalculado` → `validado`.

Alternativas justificadas: `alegação limitada`, `alegação retirada`, `dependência factual pendente`. Registrar sempre a evidência e a versão. Um defeito não reproduzido, como O09 no PDF original disponível, recebe esse diagnóstico sem inventar correção.

## Resolução após execução do ciclo

| ID | Estado final | Evidência/limite |
|---|---|---|
| O01 | Validado; escopo corrigido | Alvo de sucesso/correção explícito; teste de labels OULAD e ranking; blueprint de risco separado |
| O02 | Validado | Entropia compartilhada em bits, clipping e testes; unidades e métricas exatas no artigo |
| O03 | Implementado e validado | Pareto explícito em pseudocódigo, módulo compartilhado e runner; testes de permutação, tolerância e conjunto vazio |
| O04 | Relato corrigido; limitação declarada | Autor confirmou voluntariado, mapeamento e ausência de revisão formal; sem aprovação inventada nem divulgação de respostas |
| O05 | Recalculado e validado | Médias conferidas, IC por participante, enumeração bilateral e Holm; efeito de bundle e concordância de desfechos explicitados |
| O06 | Validado | Figura em inglês, contagens/denominadores e Description LaTeX; inspecionada no PDF |
| O07 | Validado | Contagens inteiras e grupos no JSON; K como teto, taxa de seleção distinta de cobertura |
| O08 | Validado | Grades 5x16 e subconjuntos fixos de 16 separados; escolhas e perfis com métricas completas |
| O09 | Não reproduzido no original; apresentação revisada validada | PDF final renderizado sem cortes; nenhum DOCX fornecido para comparação |
| O10 | Alegação limitada ao contrato implementado | Schema/verificador v2 e escopo por cenário; exceções médicas, dados alterados e regras por escola não apresentados como replay executado |
| O11 | Corrigido e validado | Apêndice, README/checklist e inventário reconciliados; fontes e pacote com hashes; respostas individuais excluídas |
| O12 | Recalculado e incorporado | Tabela incluída; ranks médios, ECE, risco por grupo, intervalos condicionais e limitação de clusters |
| A01 | Corrigido | Definições de seleção/cobertura alinhadas |
| A02 | Implementado e validado | Gate bloqueia exportação inviável; não alega entrega humana |
| A03 | Implementado e validado | Checks calculados; adulteração/modelo alterado/política ausente fazem verificação falhar |
| A04 | Implementado e validado | Hash de configuração separado dos bytes do modelo ajustado |
| A05 | Reconciliado | Histórico preservado; seleção revisada fixa e perfis variáveis com IDs e critérios explícitos |
| A06 | Implementado e validado | Ranking compartilhado e desempate por ID; mesmas decisões históricas e teste de permutação |
| A07 | Alegação limitada | Re-scoring e replay de scores fixos distinguidos |
| A08 | Alegação limitada | Auditoria retrospectiva no mesmo conjunto; nenhuma garantia de fairness futura |
| A09 | Corrigido e validado | Spearman com ranks médios, resultados regenerados |

A ausência de aprovação ética formal, de fila humana conectada e de avaliação prospectiva não pode ser apagada por revisão de texto. A correção é relatar fielmente o escopo e retirar inferências que dependiam dessas condições. O artigo não foi submetido e a aplicação não foi implantada.
