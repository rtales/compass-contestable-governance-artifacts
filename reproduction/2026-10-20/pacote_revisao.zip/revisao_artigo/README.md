# Revisão do artigo Governing by Artifacts

Criado em 2026-10-20. Referência temporal: America/Toronto.

## Objetivo e estado

Corrigir a coerência entre manuscrito, aplicação, experimentos e materiais de reprodução. A versão escolhida pelo autor é o projeto LaTeX `Governing_by_Artifacts__An_Auditable_Constraint_Based_Framework_for_Contestable_Educational_Decision_Systems/`.

**Estado: correção e validação concluídas no escopo documentado.** O autor solicitou o ciclo de correção e validação até concluir. Fontes anteriores foram preservados; mudanças e evidências são registradas no diário. Dados originais permanecem preservados.

## Documentos de trabalho

- [Plano passo a passo](PLANO_PASSO_A_PASSO.md): sequência, dependências, entregas e critérios de conclusão.
- [Método de execução](METODO_DE_EXECUCAO.md): como conduzir cada etapa, lotes de entrega e participação necessária do autor.
- [Matriz dos problemas](MATRIZ_DE_CORRECOES.md): as 12 observações e riscos adicionais.
- [Decisões e pendências](DECISOES_E_PENDENCIAS.md): escolhas propostas, fatos confirmados e informações ainda necessárias.
- [Validação e liberação](VALIDACAO_E_LIBERACAO.md): testes e evidências exigidos para concluir.
- [Diário de trabalho](DIARIO_DE_TRABALHO.md): histórico desta conversa e próximas ações.

## Convenção de caminhos

Os caminhos de código e dados mencionados nos documentos são relativos à pasta raiz `Projeto Compass Ciencia`, salvo indicação diferente.

- `PAPER`: projeto LaTeX escolhido, de nome longo indicado acima.
- `APP_CANDIDATA`: `compass_github/compass-contestable-governance-artifacts/`.
- `APP_HISTORICA`: `compass_artifacts_repo/`.
- `AIES`: `AIES2026/compass-audit-artifacts-pipeline/`; versão distinta, não adotada para substituir o artigo selecionado.

O uso de `APP_CANDIDATA` é uma proposta para a etapa de implementação. A etapa 1 deve reconciliar essa cópia com o código que gerou os artefatos históricos antes de escolher a base definitiva.

## Como registrar o trabalho daqui em diante

1. Antes de uma alteração, identificar o problema e a etapa do plano.
2. Depois de cada sessão ou conjunto coerente de alterações, acrescentar entrada ao diário: objetivo, arquivos, comandos relevantes, evidência, resultado e pendências.
3. Atualizar a matriz e registrar decisões novas, inclusive mudanças de interpretação.
4. Distinguir sempre: observado, calculado sob hipótese, recomendado, implementado e validado.
5. Não reescrever entradas históricas para fazer uma hipótese parecer confirmação. Acrescentar uma retificação.
6. Não copiar respostas individuais, dados pessoais, segredos ou dados educacionais sensíveis para os registros públicos. Registrar referências e resultados agregados.
7. Não marcar um item como concluído apenas porque o texto foi editado. Quando houver alegação sobre comportamento, exigir evidência do código e do teste correspondente.

Este diretório é o ponto de continuidade da revisão. Sua existência não cria monitoramento automático de trabalhos realizados fora desta conversa.

## Resultados da execução

- [Relatório final](RELATORIO_FINAL.md)
- [Inventário](INVENTARIO_DE_VERSOES.md)
- [Especificação científica](ESPECIFICACAO_CIENTIFICA.md)
- [Reconciliação numérica](RECONCILIACAO_NUMERICA.md)
- [Estudo N=16](RELATORIO_ESTUDO_N16.md)
- [Checks históricos](VERIFICACAO_ARTEFATOS_HISTORICOS.md)

O PDF revisado e o pacote reproduzível ficam em `evidencias/`. Os outputs históricos e a cópia anterior dos fontes estão preservados. A distribuição/submissão externa não faz parte desta execução.
