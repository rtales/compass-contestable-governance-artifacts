# Inventário inicial

Base de execução escolhida: `compass_github/compass-contestable-governance-artifacts/`.
Manuscrito: projeto LaTeX Governing by Artifacts selecionado pelo autor.

Snapshot anterior às alterações: `evidencias/fontes_antes_da_revisao.zip`; hashes: `evidencias/inventario_inicial.json`.

Comparação dos módulos Python com `compass_artifacts_repo/`:

| Arquivo | Idêntico à cópia histórica |
|---|---|
| src/compass/__init__.py | sim |
| src/compass/artifacts/__init__.py | sim |
| src/compass/artifacts/packets.py | sim |
| src/compass/cli.py | sim |
| src/compass/data/__init__.py | sim |
| src/compass/data/assistments.py | sim |
| src/compass/data/io.py | sim |
| src/compass/data/oulad.py | sim |
| src/compass/data/synthetic.py | sim |
| src/compass/data/validation.py | sim |
| src/compass/metrics/__init__.py | sim |
| src/compass/metrics/contestability.py | sim |
| src/compass/metrics/fairness.py | sim |
| src/compass/metrics/utility.py | sim |
| src/compass/models/__init__.py | sim |
| src/compass/models/base.py | sim |
| src/compass/models/numpy_linear.py | sim |
| src/compass/models/registry.py | sim |
| src/compass/models/sklearn_logreg.py | sim |
| src/compass/pipeline/__init__.py | sim |
| src/compass/pipeline/run.py | sim |
| src/compass/policy/__init__.py | sim |
| src/compass/policy/decision.py | sim |
| src/compass/reporting/__init__.py | sim |
| src/compass/reporting/bundle.py | sim |
| src/compass/reporting/decision_brief.py | sim |
| src/compass/snapshots/__init__.py | sim |
| src/compass/snapshots/fetch.py | sim |
| src/compass/utils/__init__.py | sim |
| src/compass/utils/env.py | sim |
| src/compass/utils/hashing.py | não |
| src/compass/utils/io.py | sim |
| src/compass/utils/net.py | sim |
| src/compass/utils/seeds.py | não |

A identidade das fontes não prova qual ambiente gerou os artefatos. Os outputs de 2026-01-26 serão reconciliados diretamente. O estudo AIES N=18 fica excluído.

Arquivos preservados: 145. A raiz não possui Git. HEAD da aplicação: c6430dc223659aa0b5ede0598b7021709602d918; havia alterações locais anteriores em metadata e arquivos não rastreados, preservados.
