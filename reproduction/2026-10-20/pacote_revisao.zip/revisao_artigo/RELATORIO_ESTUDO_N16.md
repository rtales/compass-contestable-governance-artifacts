# Estudo original N=16 — análise revisada

Atribuição confirmada pelo autor em 2026-10-20: G1 ímpares=A, pares=B; G2 inverso. Participação voluntária. O autor confirmou autorização e declarou ausência de aprovação/dispensa formal por comitê. O arquivo de respostas contém um campo de consentimento; não se infere daí aprovação institucional. Não houve envio de dados individuais.

Retrospective revision; two-sided exact sign enumeration of nonzero Wilcoxon midranks; Holm over four endpoints; 10000 participant bootstrap replicates, seed 42.

| Desfecho | A | B | Diferença | IC95% | p Holm |
|---|---:|---:|---:|---|---:|
| diagnosis | 0.562500 | 0.921875 | 0.359375 | [0.203125, 0.515625] | 0.00292969 |
| remediation | 0.562500 | 0.921875 | 0.359375 | [0.203125, 0.515625] | 0.00292969 |
| confidence | 3.078125 | 4.234375 | 1.156250 | [0.921875, 1.375] | 0.00012207 |
| evidence_characters | 69.812500 | 91.656250 | 21.843750 | [20.046875, 23.734375] | 0.00012207 |

Os p-values mudam em relação ao original porque a revisão usa um único procedimento bilateral, com enumeração dos sinais e Holm, em vez de misturar aproximações e enumeração unilaterais. A escolha é retrospectiva e não foi feita para preservar significância.

Recrutamento detalhado, datas, compensação e instrumento completo de consentimento não foram documentados no pacote inspecionado. O texto relata esses limites; não inventa detalhes. O estudo não separa os efeitos de mais informação, proveniência e replay, nem demonstra um motor executável para as exceções dos cenários.
