# Diário de trabalho

Referência temporal: America/Toronto. Entradas anteriores à criação deste arquivo são retrospectivas da conversa, sem horários inventados.

## 2026-10-20 — Registro retrospectivo: seleção e análise do artigo

**Solicitação:** analisar o artigo disponível no projeto.

**Decisão do autor:** usar a versão LaTeX de Governing by Artifacts, pasta com `main.tex` e `sections/`. A versão AIES/Policy Replay não foi escolhida.

**Ações realizadas:** leitura de seções, tabelas e apêndices; identificação de divergências de cobertura, alvo, orçamento, pseudocódigo e descrição da avaliação humana. Consulta a registro primário da referência Contestable AI by Design identificou dados bibliográficos incompatíveis com o BibTeX local.

**Resultado:** parecer de revisão maior, com foco em alinhar definições, evidências e alegações. Não houve edição do manuscrito ou do código.

## 2026-10-20 — Registro retrospectivo: auditoria das 12 observações

**Solicitação:** distinguir problemas do artigo original de possíveis problemas da conversão DOCX.

**Ações realizadas:** buscas no projeto; leitura de código de dados, decisão, métricas, pipeline, pacotes e scripts auxiliares; inspeção dos CSVs de sweeps e JSONs de seleção; conferência de pacotes históricos; inspeção da figura original; renderização da página 9 do PDF original; leitura e recomputação agregada dos CSVs do estudo N=16.

**Ausência relevante:** nenhum `.docx` foi encontrado na árvore pesquisada. Não houve comparação direta LaTeX–DOCX.

**Resultados observados:**

- Código OULAD usa positivo `Pass/Distinction`; ranking descendente; utilidade como proporção de positivos selecionados.
- Entropia dos pacotes conferidos corresponde à função em bits; script auxiliar de temperatura recalcula com log natural.
- Grades históricas: 80 candidatos por dataset, com 5 valores de K e 16 de gamma; viáveis sob cobertura >=0.5 e gap absoluto <=0.05: 55 ASSISTments, 15 OULAD e 12 sintético.
- Pacotes iniciais: ASSISTments n=105107, select=1000, reject=78730, abstain=25377; OULAD n=6519, select=69, reject=0, abstain=6450; sintético n=1000, select=4, reject=0, abstain=996.
- JSONs `*_mas_selection.json`: gamma=0.999; cobertura 0.9994481813770729, 0.906427366160454 e 0.933, respectivamente. Isso confere os arquivos e não significa validação independente de todo o treinamento.
- Script de estabilidade tem Pareto antes de MAS; pseudocódigo não explicita essa etapa. Runner de recipe única não demonstra seleção completa de candidatos.
- Tabela 11 está inteira no PDF original inspecionado, página 9. Há problemas visuais em outros elementos, mas não foi atribuída uma falha ao DOCX sem o arquivo.
- Figura original tem título/eixos em português.
- Estimativas de ECE/correlação existem em tabela e JSON locais; a tabela não está incluída nas seções compiladas.
- Schema mínimo não contém todos os insumos das exceções ilustradas no appeal pack.

**Recomputação do estudo, condicionada a hipótese explícita:** G1 recebe casos ímpares em A e pares em B; G2 recebe atribuição inversa. Essa configuração reproduz os agregados, mas precisa de confirmação pelo protocolo original.

| Medida | A | B |
|---|---:|---:|
| Diagnóstico | 0.562500 | 0.921875 |
| Remediação | 0.562500 | 0.921875 |
| Confiança | 3.078125 | 4.234375 |
| Comprimento da evidência em caracteres | 69.812500 | 91.656250 |

Foram encontradas 16 pessoas identificadas por IDs e 128 respostas por caso. Acerto diagnóstico e acerto de remediação coincidem em 128/128 respostas. Não se concluiu por isso que os dados têm proveniência ou validade externa comprovadas.

Para acurácia, cálculo de postos médios, exclusão de 3 diferenças zero, teste unilateral e aproximação normal sem continuidade reproduziu p=0.0013147568071905013. Enumeração de sinais produziu p=0.000732421875. Para confiança e comprimento, enumeração produziu p=0.0000152587890625. São verificações sob configurações explícitas; não substituem documentação do teste originalmente usado.

**Limitações da verificação:** não houve novo treinamento nem rerun integral do projeto. O ambiente Python usado não tinha SciPy; o cálculo de Wilcoxon foi conferido por fórmula de postos e enumeração, não por uma chamada ao software histórico. Um primeiro comando com import SciPy falhou e foi substituído por cálculo explícito. Ações de extração/renderização produziram apenas intermediários em `/tmp`.

## 2026-10-20 — Planejamento e criação do registro permanente

**Solicitação:** plano passo a passo abrangendo texto e código; registro em Markdown em subpasta específica.

**Ações:** criado `revisao_artigo/` com README, plano, matriz, decisões/pendências, protocolo de validação e este diário. Realizadas leituras adicionais dos READMEs, checklist, recipe/perfil e teste de recipe sintética para localizar documentação divergente.

**Proveniência local:** raiz do projeto sem Git. APP_CANDIDATA possui Git e HEAD observado `c6430dc223659aa0b5ede0598b7021709602d918`. Havia modificação em metadata egg-info e arquivos não rastreados, inclusive outputs, antes de qualquer implementação desta revisão. Nenhum desses itens foi revertido ou limpo. O HEAD não identifica sozinho a origem de todos os resultados históricos.

**Decisões de planejamento:** corrigir semântica antes de recalcular; manter trilhas histórica/corrigida; não usar estudo N=18 para preencher lacunas do N=16; limitar replay a contrato comprovado; exigir teste real para fail-closed e scorecard; não publicar/submeter nesta etapa.

**Verificação desta entrega:** executado script de leitura dos Markdown com a biblioteca padrão do Python. Resultado: seis documentos presentes, todos os links internos para Markdown válidos e observações O01–O12 presentes na matriz. A checagem confirma a organização do plano; não valida o código da aplicação nem executa os testes técnicos planejados.

**Próxima ação proposta:** etapa 1 — inventário imutável e reconciliação da base de código, seguida da especificação científica.

## 2026-10-20 — Detalhamento do método de execução

**Solicitação:** explicar como realizar a revisão passo a passo.

**Ações:** leitura dos registros existentes; criação de `METODO_DE_EXECUCAO.md`; inclusão no README. Documentados ciclo de alteração/verificação/registro, sete lotes de entrega e informações que podem depender do autor.

**Resultado:** execução explicada sem iniciar alterações no artigo ou na aplicação. O primeiro lote continua pendente. O método não exige confirmações de rotina durante trabalho autorizado, mas preserva decisões científicas e fatos não documentados como pendências explícitas.

## Modelo para próximas entradas

```text
## AAAA-MM-DD — Título da sessão
Solicitação/objetivo:
Etapas e IDs da matriz:
Arquivos lidos/alterados:
Ações e comandos relevantes:
Testes/verificações e resultados:
Decisões e justificativas:
Limitações/erros/retificações:
Próxima ação:
```

## 2026-10-20 — Execução do loop: inventário, núcleo e testes iniciais

**Autorização:** autor pediu execução iterativa até concluir. Confirmou o mapeamento experimental, participação voluntária e ausência de aprovação/dispensa formal por comitê.

**Preservação:** 145 arquivos de fontes/assets preservados em ZIP com inventário SHA-256. Base escolhida: cópia compass_github com Git, 32/34 módulos idênticos à cópia histórica. Outputs antigos não alterados.

**Código:** núcleo compartilhado de entropia/decisão, métricas com estados insuficientes explícitos, ECL/Pareto/MAS, schema 2.0, verificação de pacotes e replay, hashes do modelo ajustado/fontes, bloqueio de exportação e estado explícito sem fila humana. Integração de seleção finita ao runner em andamento.

**Verificação inicial:** 14 testes passaram antes da última integração de busca de políticas. A bateria será repetida após completar as mudanças. Primeiro patch foi rejeitado por duplicação de operação no mesmo arquivo; não houve alteração parcial e a aplicação corrigida foi feita com update. Download de dependências falhou por DNS no sandbox; execução com acesso de rede autorizado instalou ambiente isolado. Tectonic oficial foi baixado localmente e compilou a versão de partida, preservada como original_recompilado.pdf. Isso não valida a versão revisada.

**Análises:** script permanente de recomputação criado; execução em andamento. Não houve re-treinamento dos modelos históricos; testes de integração treinam fixtures sintéticas isoladas.

## 2026-10-20 — Fechamento do ciclo de correção e validação

**Texto e código:** especificação científica registrada; runner e scripts compartilham decisão/entropia; ECL/Pareto/MAS e schema/verificador foram integrados. Descrições de dados conferidas contra processadores, incluindo preenchimento de missing em vez da remoção de linhas descrita anteriormente. App histórica, dados e respostas não foram sobrescritos.

**Reanálise:** grades, estados e incerteza recalculados; todos os estados iniciais históricos coincidiram. Na primeira execução, serialização estrita rejeitou NaN na comparação de células indefinidas; o script passou a comparar valores finitos e padrões de ausência separadamente. Não se substituiu utilidade indefinida por zero. Foram gerados relatórios de grupos, intervalos e estudo N=16; nenhuma resposta individual entrou nos outputs derivados.

**Validação técnica:** 16 testes passaram localmente e 16 na cópia extraída. Runs sintéticos persistidos exercitaram autorização viável e bloqueio inviável com checks reais. Um primeiro check estático de referências tratou exemplo em comentário como referência ativa; foi corrigido para ignorar comentários e passou com 35 labels/zero referências indefinidas. Execuções diagnósticas anteriores foram mantidas, sem serem apresentadas como resultados finais.

**PDF:** Tectonic precisou baixar uma fonte matemática adicional após falha de DNS em execução restrita; a repetição com rede autorizada compilou. Ajustes de quebra de linha e tabela de cenários eliminaram overfull boxes. Resultado final: 10 páginas renderizadas, todas examinadas, com reinspeção das quatro páginas modificadas por último. Sem cortes de tabela.

**Portabilidade:** pacote extraído em pasta temporária; hashes conferidos. Reanálise computacional sem respostas humanas produziu JSON e três grades CSV idênticos byte a byte. Não se afirmou que o estudo foi reexecutado sem seus dados. O mesmo ambiente isolado foi usado; seu lock e a origem do Tectonic estão registrados. Fontconfig usou cache temporário e emitiu avisos; não houve erro numérico ou de saída.

**Fechamento:** matriz e critérios atualizados; diferenças de fontes registradas em JSON; relatório final e pacote com checksums preparados. Não houve implantação, submissão ou compartilhamento externo. Limitações históricas/institucionais foram declaradas, sem dados ou procedimentos inventados.
