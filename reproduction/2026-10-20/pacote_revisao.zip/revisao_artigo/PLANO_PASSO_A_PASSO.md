# Plano passo a passo

Data: 2026-10-20. Estado: executado no escopo de correção técnica e editorial; ver RELATORIO_FINAL.md e estados da matriz.

## Princípio de execução

Primeiro fixar as definições e a proveniência; depois corrigir o comportamento; então recalcular os resultados; finalmente reescrever e renderizar o artigo. Ajustar a narrativa antes de resolver as divergências numéricas pode apenas ocultar o problema.

Há duas trilhas diferentes: **reconstrução histórica**, que identifica o que foi realmente executado, e **execução corrigida**, que produz novos resultados sob especificação explícita. Ambas devem preservar seus identificadores. Resultados novos não devem ser apresentados como reprodução exata dos antigos.

## 1. Congelar e inventariar a versão de partida

**Dependências:** nenhuma. **Problemas:** O09, O11 e proveniência geral.

- Inventariar o LaTeX escolhido, arquivos efetivamente incluídos, imagens, tabelas, scripts, recipes, pacotes por caso e dados do estudo N=16.
- Registrar checksums dos insumos, revisões Git quando existirem e alterações locais. A raiz do projeto não é um repositório Git.
- Comparar `APP_CANDIDATA` e `APP_HISTORICA` nos módulos de dados, decisão, métricas, pacotes e pipeline; identificar qual revisão explica cada execução histórica.
- Preservar os outputs históricos. Trabalhar em saídas novas, com IDs e diretórios próprios.
- Tratar arquivos AIES de N=18 como outra versão. Não usar seus participantes ou protocolo para completar retrospectivamente o estudo N=16.
- Se o DOCX for disponibilizado, acrescentá-lo ao inventário e comparar texto, imagens, tabelas e notas. A ausência dele não impede corrigir os problemas já comprovados no original.

**Entrega planejada:** `INVENTARIO_DE_VERSOES.md`, com tabela arquivo → hash → origem → papel → condição de inclusão.

**Conclusão:** uma base de código definida e cada resultado histórico associado a seus insumos, ou explicitamente marcado como não rastreado.

## 2. Especificar tarefa, alvo, ranking e semântica das métricas

**Dependências:** etapa 1. **Problemas:** O01, O07, O08 e cobertura inconsistente.

- Descrever por dataset: unidade de decisão, população, split, horizonte, classe positiva, score, direção do ranking e significado da intervenção.
- Para preservar o estudo computacional atual, adotar como proposta a descrição honesta de predição de sucesso/correção. Alerta precoce passa a proposta futura claramente separada.
- Se o autor optar por avaliar risco de evasão, criar recipe e snapshot versionados, definir janela temporal e prevenção de vazamento, reexecutar treinamento e avaliação. Não inverter o alvo apenas nas tabelas.
- Separar `selection_rate = n_select/n`, `automation_coverage = (n_select+n_reject)/n` e `abstain_rate = n_abstain/n`.
- Definir K como limite, não promessa de preenchimento, e reportar `n_eligible`, `n_selected`, `n_rejected`, `n_abstained`.
- Definir explicitamente allocation/screening e a localização da abstenção. No screening, demonstrar `automation_coverage <= K/n`; não interpretar a troca de encaminhamento por rejeição como benefício social comprovado.
- Especificar denominadores da equidade, comportamento com grupos sem positivos, grupos ausentes e seleção vazia. Dados insuficientes devem gerar estado explícito, não equidade perfeita por convenção silenciosa.
- Definir quais resultados são de avaliação retrospectiva com labels disponíveis e quais decisões são possíveis em produção antes da observação de y.

**Entrega planejada:** `ESPECIFICACAO_CIENTIFICA.md` e schemas/configurações versionados.

**Conclusão:** cada termo do manuscrito tem uma definição única e operacional; decisões substantivas estão registradas.

## 3. Unificar entropia, aplicação de política e desempates por caso

**Dependências:** etapa 2. **Problemas:** O02, O07, O10.

- Usar uma função compartilhada de entropia binária em bits, com base 2 e máximo 1; registrar epsilon e tratamento de probabilidades 0/1 e entradas inválidas.
- Fazer scripts de validação, sweeps e replay chamarem a mesma implementação, eliminando a mistura atual de `log` e `log2`.
- Registrar convenção de entropia no manifesto e no esquema dos pacotes; rejeitar limiares incompatíveis ou exigir conversão explícita de unidades.
- Centralizar a regra de decisão com modos e direção de ranking explícitos. Preservar os modos históricos identificados sem fingir que todos já tinham suporte no runner.
- Desempatar scores por ID de caso estável e persistido, independente da ordem de entrada. Não usar só a posição transitória no array como identidade entre execuções.
- Diferenciar capacidade de intervenção K de capacidade da fila humana; representar eventual limite de revisão humana como restrição distinta.

**Arquivos-alvo:** `src/compass/policy/decision.py`, métricas de utilidade, emissão de pacotes e scripts `PAPER/code/`.

**Conclusão:** aplicação original e replay compartilham semântica e produzem decisões idênticas quando recebem os mesmos insumos.

## 4. Tornar ECL e MAS verificáveis no fluxo completo

**Dependências:** etapas 2–3. **Problemas:** O03, O08 e garantias excessivas.

- Implementar ou consolidar a sequência candidatos → viabilidade → Pareto → perfil MAS → candidato escolhido. O script auxiliar já tem Pareto; o runner de recipe única não demonstra sozinho esse fluxo completo.
- Distinguir seleção com orçamento fixo de comparação de políticas com orçamento variável. Registrar o domínio de busca de cada execução.
- Especificar objetivos de Pareto, direções, tratamento de NaN, precisão e se a dominância é exata ou usa tolerância.
- Definir tolerância por critério, ordenação lexicográfica, desempate final por candidate ID e comportamento no conjunto vazio. Evitar alteração dos resultados por simples permutação das linhas.
- Tornar explícito o estado `feasible`, `infeasible` ou `insufficient_evidence`; manter relatório de violações.
- Para sustentar fail-closed operacional, impedir que uma execução inviável seja disponibilizada como decisão implantável. Preservar as decisões candidatas para auditoria, separadas de qualquer saída efetiva autorizada. Encaminhamento humano deve ter evento/estado verificável.
- Se a aplicação for apenas offline, limitar a alegação a bloqueio de exportação/autorização e sinalização de necessidade de revisão; não afirmar que uma pessoa efetivamente recebeu ou resolveu o caso.
- Substituir scorecard preenchido com constantes por verificações de schema, hashes, consistência, disponibilidade dos insumos e replay real. Hash consistente não comprova veracidade do dado nem autenticidade externa.

**Arquivos-alvo:** pipeline, schemas de política, módulos de seleção/validação, `PAPER/code/stability_eval.py`, pseudocódigo e garantias G1–G3.

**Conclusão:** casos inviáveis, empates e entradas permutadas têm comportamento documentado e testado de ponta a ponta.

## 5. Delimitar o contrato de artefatos e o alcance do replay

**Dependências:** etapas 2–4. **Problemas:** O10, O11.

- Versionar schema mínimo para replay com scores fixos: identidade, score, entropia/unidade, grupo de auditoria quando necessário, decisão, referências e hashes.
- Persistir o conteúdo recuperável da política, não apenas seu hash; incluir modo, ranking, limiares, K, tolerâncias, candidate ID e versão do código.
- Separar label retrospectivo de insumos de decisão. Não exigir ground truth futuro para reconstruir uma decisão em produção.
- Corrigir o significado de `model_hash`: o código inspecionado calcula hash da configuração; registrar separadamente configuração e artefato efetivamente ajustado, preprocessing e versão.
- Limitar a promessa principal do artigo ao replay que a implementação suporta.
- Para exceções normativas, escolher explicitamente entre implementar schema e motor com todos os insumos necessários ou apresentar os casos apenas como cenários ilustrativos de documentação, sem alegar replay executável.
- Mudança de renda, remoção de CEP ou mudança de features exige re-scoring e possivelmente novo modelo; não é replay de scores fixos. Classificar corretamente cada cenário do appeal pack.
- Se houver extensão de schema, armazenar apenas o necessário, com referências recuperáveis e controles adequados; evitar dados médicos brutos em pacotes públicos.
- Validar reconstrução contra decisões originais e testar adulteração, política ausente, insumo ausente, unidades divergentes e versões incompatíveis.

**Entrega planejada:** especificação versionada do contrato, exemplos mínimos e relatório de replay por cenário.

**Conclusão:** toda alegação de replay aponta para uma demonstração executável; limitações estão descritas no artigo.

## 6. Reproduzir e regenerar os experimentos computacionais

**Dependências:** etapas 3–5. **Problemas:** O02, O07, O08, O09.

- Reconciliar primeiro os runs históricos com hashes/políticas, contagens inteiras e métricas sem arredondamento.
- As grades históricas encontradas têm 80 pontos = 5 valores de K × 16 de gamma por dataset. Identificar formalmente os subconjuntos de K fixo, com suas próprias contagens de candidatos/viáveis/Pareto.
- Recalcular viabilidade, fronteiras, perfis e escolhas a partir dos pacotes. Comparar com CSVs e JSONs históricos, sem sobrescrevê-los.
- Reconciliar arquivos `*_selected.json` e `*_mas_selection.json`: há escolhas diferentes em ASSISTments/OULAD que precisam de nome de perfil e justificativa, não seleção manual de um arquivo conveniente.
- Reportar em cada ponto escolhido K, gamma/unidade, n, contagens por estado e grupo, utilidade, equidade, cobertura, perfil e critérios ativos.
- Gerar tabelas, macros LaTeX e dados de figuras de um único relatório estruturado. Aplicar arredondamento somente na apresentação.
- Medir runtime apenas se houver alegação de custo; documentar hardware, escala e operações incluídas. Não substituir custo institucional por tempo de CPU.
- Caso se mantenha garantia fora da amostra ou estabilidade entre treinamentos, usar separação validação/teste e desenho com seeds definido antes de rodar. Caso contrário, limitar a alegação ao conjunto auditado.

**Entrega planejada:** `RECONCILIACAO_NUMERICA.md`, relatórios estruturados e assets regenerados.

**Conclusão:** cada célula reportada tem fonte, script e execução identificáveis; diferenças históricas estão explicadas.

## 7. Completar a validação da incerteza

**Dependências:** etapas 3 e 6. **Problemas:** O02, O12.

- Recalcular ECE com bins definidos e tratamento explícito do score 1, correlação com ranking médio para empates e testes de temperatura com unidade consistente.
- Reportar amostra, contagens por grupo, número de bins e convenção de erro/risco. ECE mede calibração; não prova isoladamente qualidade da abstenção.
- Reportar risco seletivo, cobertura e composição por grupo ao longo dos limiares, com intervalos que respeitem a unidade amostral e eventual dependência entre interações do mesmo estudante.
- Separar métricas retrospectivas calculadas com y de políticas aplicáveis sem y em produção.
- Inserir no build a tabela que já existe, depois de regenerada e verificada. Corrigir claim-evidence map e referências cruzadas.
- Descrever honestamente calibração fraca no sintético e limites no OULAD, sem transformar correlação em garantia de segurança ou medida de compreensão humana.

**Conclusão:** o leitor vê os números, a definição e as limitações no documento compilado; artefatos permitem recomputação.

## 8. Auditar o estudo original N=16

**Dependências:** inventário da etapa 1. Pode avançar independentemente das etapas 3–7.
**Problemas:** O04, O05, O06, O11.

- Preservar os oito CSVs, gabaritos e materiais de cada condição. Confirmar documentalmente o mapeamento G1/G2, casos e ordens; a recomputação anterior usou uma atribuição compatível com as médias, ainda não confirmada pelo protocolo.
- Solicitar/recuperar informações factuais ausentes: recrutamento, datas, treinamento, randomização, consentimento, revisão ética/dispensa quando aplicável, compensação e exclusões. Não inventar aprovação retrospectiva nem transportar dados da versão N=18.
- Auditar número de participantes únicos, completude, duplicações, missing, respostas excluídas e se o gabarito/remediação realmente discriminam tarefas diferentes.
- Explicitar unidade de comprimento da evidência; a contagem de caracteres reproduz os agregados históricos. Não interpretar comprimento maior como qualidade melhor sem rubrica.
- Construir script reproduzível de análise por participante, com software/versões, hipótese unilateral/bilateral, zeros, empates, método de p-value e correção de continuidade.
- Registrar plano analítico de revisão como retrospectivo. Escolher método adequado e reportar divergências, sem escolher opções apenas para recuperar os p-values antigos.
- Reportar diferenças pareadas, efeito em unidades interpretáveis e intervalos por reamostragem de participantes, com método e seed. Especificar desfechos principais e tratamento de múltiplos testes, por exemplo Holm para a família definida.
- Explicar a coincidência entre acerto diagnóstico e remediação, observada em 128/128 respostas por caso; não alegar duas evidências independentes.
- Regenerar figura em inglês com acertos/denominadores por caso e condição, legenda informativa e texto alternativo.
- Separar efeito do pacote completo de efeito específico de replay. Ablação ou estudo independente ficam como extensão prospectiva se forem necessários para ampliar a alegação, sem condicionar a revisão mínima a uma nova coleta.
- Preparar dados derivados desidentificados apenas se consentimento e regras de compartilhamento permitirem; caso contrário, documentar restrição e fornecer scripts, esquema e agregados permitidos.

**Entregas planejadas:** `RELATORIO_ESTUDO_N16.md`, script e resultados agregados rastreáveis; pendências institucionais documentadas.

**Conclusão:** números reproduzidos, mapeamento confirmado ou limitação declarada, documentação factual recuperada ou alegação reduzida. Se a evidência essencial não puder ser sustentada, retirar a alegação correspondente em vez de preenchê-la por inferência.

## 9. Reescrever o manuscrito conforme a evidência final

**Dependências:** etapas 2, 4–8.

- Resumo e introdução: contribuição de infraestrutura e escopo demonstrado; remover custo limitado ou impacto operacional não medido.
- Notação/método: definições únicas, entropia em bits, estados, K limite, ordem de seleção, Pareto, tolerâncias, IDs e ramo de inviabilidade.
- Experimentos: tarefas efetivamente executadas, grids e subconjuntos, splits, labels e separação entre avaliação retrospectiva e produção.
- Resultados: métricas geradas, denominadores e incerteza; distinguir avaliação histórica de execução corrigida.
- Discussão: reclassificação de decisões muda responsabilidades; maior cobertura automatizada não demonstra melhor atendimento. Explicar limitações de grupos sintéticos e labels históricos.
- Apêndices B/C/D/E: eliminar contradições entre inventário, blueprint futuro, tarefas reais e schema. Atualizar também README e checklist antigos que dizem “No User Study” ou invertem A/B.
- Claim-evidence map: cada afirmação ligada a seção, figura/tabela incluída e teste/artefato existente; remover referência órfã.
- Referências: corrigir bibliografia e verificar registros primários. Avaliar afirmações jurídicas apenas contra fontes oficiais atuais, sem prometer conformidade automática.
- Cenários de recurso: separar demonstração computacional, material experimental e requisitos de uma implantação futura.

**Conclusão:** nenhuma afirmação forte depende só de intenção de design ou de um arquivo que não entra no build.

## 10. Compilar, renderizar e conferir a apresentação

**Dependências:** etapa 9.

- Compilar o projeto com todos os includes e bibliografia; examinar logs, referências indefinidas, labels repetidos e overfull boxes.
- Renderizar e inspecionar todas as páginas, incluindo anexos, figuras, notas e tabelas largas.
- Conferir inglês nos gráficos, legibilidade, limites de página, texto alternativo e unidades.
- Comparar valores visíveis com relatório estruturado e contagens originais; não reconstruir valores exatos a partir de células arredondadas.
- Se houver DOCX autorizado como entrega, gerá-lo somente após estabilizar a fonte, registrar a ferramenta e repetir a inspeção de texto/tabelas/renderização nele. Não usar correção manual exclusiva no Word como nova fonte científica.

**Conclusão:** PDF verificado visualmente e numericamente; problema de recorte atribuído à versão correta, se ocorrer.

## 11. Executar a validação integrada e preparar a liberação

**Dependências:** etapas 1–10.

- Rodar os testes relevantes descritos em `VALIDACAO_E_LIBERACAO.md`, uma reconstrução histórica possível e uma execução corrigida em ambiente limpo documentado.
- Gravar revisão imutável ou snapshot com checksums, ambiente, receitas, scripts e inventário efetivo. `LOCAL` não identifica uma revisão de código.
- Verificar pacote de reprodução a partir dos arquivos que ele realmente contém, incluindo caminho offline quando permitido pelos datasets.
- Atualizar matriz, diário e decisões com evidência de cada conclusão. Não publicar dados individuais nem enviar/submeter o artigo nesta etapa sem instrução específica.
- Apresentar ao autor comparação de alegações e números antes/depois, problemas resolvidos e limitações remanescentes.

**Conclusão global:** as 12 observações têm resposta verificável; divergências que não puderem ser resolvidas estão explicitadas e as alegações correspondentes foram limitadas ou retiradas.

## Ordem e prioridades

- **P0 — validade:** etapas 1–5; alvo, cobertura, entropia, seleção, fail-closed e alcance real do replay.
- **P1 — evidência:** etapas 6–8; resultados computacionais, incerteza e estudo N=16.
- **P2 — comunicação e entrega:** etapas 9–11; reescrita, apresentação e pacote reproduzível.

A etapa 8 pode avançar enquanto os experimentos computacionais são corrigidos. Isso descreve dependências e não autoriza delegação ou criação de novos chats.
