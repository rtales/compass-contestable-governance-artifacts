# Decisões, fatos e pendências

Atualizado em 2026-10-20.

## Decisões já dadas pelo autor

| ID | Decisão | Fonte |
|---|---|---|
| D01 | Analisar o LaTeX de Governing by Artifacts, com main.tex e sections | Confirmação explícita na conversa |
| D02 | Planejar correções de texto e código | Solicitação atual |
| D03 | Registrar o trabalho em arquivos Markdown de uma subpasta específica | Solicitação atual; pasta criada: revisao_artigo |

## Propostas técnicas para execução

Estas escolhas são recomendações do plano, não resultados implementados nem decisões já confirmadas pelo autor.

| ID | Proposta | Motivo e consequência |
|---|---|---|
| P01 | Preservar tarefa histórica de sucesso/correção e separar alerta precoce como futuro | Corrige interpretação sem fingir que resultados existentes avaliam outro alvo |
| P02 | Se houver prioridade por risco, criar experimento novo versionado | Requer alvo, janela, ranking e utilidade coerentes, com nova avaliação |
| P03 | Usar bits para entropia em todo o fluxo | É a convenção dos pacotes e da função de decisão inspecionados |
| P04 | Adotar uma implementação compartilhada de decisão e seleção | Evita divergência entre runner, replay, sweeps e texto |
| P05 | Usar APP_CANDIDATA como base após comparação histórica | Tem repositório Git; a escolha definitiva depende da etapa 1 |
| P06 | Escopo principal de replay limitado a scores fixos e políticas suportadas | Evita prometer exceções/transformações de features ausentes do schema |
| P07 | Registrar análise revisada do estudo como retrospectiva | Não existe base para alegar pré-registro após examinar resultados |
| P08 | Gerar números de publicação a partir de um relatório único | Elimina edição manual de células e complementos de valores arredondados |

## Informações necessárias antes de encerrar a revisão

- Protocolo de atribuição G1/G2 e ordens O1–O4 do estudo N=16. O mapeamento que reproduz os agregados ainda depende de confirmação documental.
- Recrutamento, datas, treinamento, consentimento efetivo, compensação e posição institucional sobre revisão ética ou dispensa. O campo de consentimento no formulário não substitui todo esse histórico.
- Permissão de compartilhamento dos dados do estudo e condições de desidentificação.
- Horizonte e finalidade educacional desejados se o autor escolher ampliar a avaliação para alerta precoce.
- Identificação de qual perfil/execução gerou cada arquivo de seleção histórico.
- DOCX e eventual PDF derivado, somente para atribuir mudanças de conversão; não são necessários para corrigir os problemas já constatados no LaTeX.

Recuperar primeiro informação já presente nos arquivos. Solicitar ao autor apenas fatos que não possam ser inferidos de forma confiável. Pendências factuais não devem impedir tarefas técnicas independentes, mas não podem ser preenchidas por suposição.

## Fatos que não devem ser reinterpretados como problemas inventados pelo DOCX

- A divergência entre blueprint de risco e recipe de sucesso aparece no original.
- A imagem em português aparece no original.
- A contradição do Apêndice B aparece no original.
- Os agregados idênticos de diagnóstico/remediação são compatíveis com as respostas encontradas.
- A Tabela 11 está completa no PDF original inspecionado; não atribuir recorte ao LaTeX sem outra evidência.
- Valores numéricos de ECE/correlação existem no projeto, mas a tabela não é incluída no corpo compilado.

## Limites de autorização desta etapa

O pedido atual é produzir o plano e os registros. Não implica iniciar nova coleta, publicar dados, submeter artigo, enviar mensagens a terceiros ou executar implantação. Alterações científicas e de aplicação ainda não foram realizadas nesta etapa.

## Atualização durante a execução

O autor autorizou a execução por ciclo de diagnóstico, correção e teste. Confirmou G1 ímpares=A/pares=B e G2 inverso, participação voluntária e autorização. Confirmou explicitamente que não houve aprovação nem dispensa formal por comitê. Não se atribui aprovação institucional ao estudo. Nenhum dado individual será publicado nesta revisão. A proposta P01 foi adotada para preservar a tarefa histórica, sem criar um novo experimento de risco.
